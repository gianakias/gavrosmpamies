<?php
session_start();
//$session_id_1 =session_id();
//session_write_close();
$pdb = $_POST['pdb'];
$lig = $_POST['lig'];
$graft = $_POST['graft'];
$check = $_POST['check'];
$len_no_bon = $_POST['len_no_bon'];
$len_bon = $_POST['len_bon'];
$sigma =$_POST['sigma'];
$epsilon =$_POST['epsilon'];
$session_id_1 = $_POST['ses'];

if ((!empty($pdb)) and ((!empty($lig)) and (!empty($graft)) and ($check == "false") and (!empty($len_no_bon)) and (!empty($len_bon)) and (!empty($sigma)) and (!empty($epsilon))) ) {
    $parameters= fopen ("uploads/".$session_id_1."/parameters.txt","w");
    $mydata1= $pdb." and ".$lig." and ".$graft." and ".$check." and ".$len_no_bon." and ".$len_bon." and ".$sigma." and ".$epsilon;
    fwrite ($parameters, $mydata1);
    fclose ($parameters);
    $_SESSION['bon']= "_no_bonded";
    session_write_close();
    //header('Location: preloader.php');
    //session_destroy();
    $command = escapeshellcmd('./.trigger.sh '.$session_id_1);
    $output = shell_exec("$command");
    echo "Fygame";
    //header('Location: downloads.php');
    //header('Location: preloader.php');
    //echo $pdb." and ".$lig." and ".$graft." and ".$check." and ".$len_no_bon." and ".$len_bon." and ".$sigma." and ".$epsilon;
    //if (((!empty($pdb)) and (!empty($lig)) and (!empty($graft)) and (!empty($sigma)) and (!empty($epsilon))) and ((($check == "false") and (!empty($len_no_bon))) and (($check == "false") and ($len_no_bon != '0')) or ($check == "true"))){
} elseif ((!empty($pdb)) and ((!empty($lig)) and (!empty($graft)) and ($check == "true") and (!empty($len_bon)) and (!empty($sigma)) and (!empty($epsilon))) )  {
    $parameters= fopen ("uploads/".$session_id_1."/parameters.txt","w");
    $mydata1= $pdb." and ".$lig." and ".$graft." and ".$check." and ".$len_no_bon." and ".$len_bon." and ".$sigma." and ".$epsilon;
    fwrite ($parameters, $mydata1);
    fclose ($parameters);
    $_SESSION['bon']= "_bonded";
    session_write_close();
    //header('Location: preloader.php');
    //session_destroy();
    $command = escapeshellcmd('./.trigger.sh '.$session_id_1);
    $output = shell_exec("$command");
    echo "Fygame1";
    //header('Location: downloads.php');
} else{
    echo "Something is not completed.. Check again....";
}

?>
