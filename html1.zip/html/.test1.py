#!/usr/bin/env python
import os,sys
import numpy as np
import json
import pandas as pd
import math
import re
from scipy.spatial import ConvexHull



def rot_matrix(x,y):
    #curve_vec_1=[0.043477,0.036412,0.998391]
    curve_vec_1=x
    curve_vec_2=y
    a,b = (curve_vec_1/ np.linalg.norm(curve_vec_1)).reshape(3), (curve_vec_2/ np.linalg.norm(curve_vec_2)).reshape(3)
    v = np.cross(a,b)
    c = np.dot(a,b)
    s = np.linalg.norm(v)
    I = np.identity(3)
    vXStr = '{} {} {}; {} {} {}; {} {} {}'.format(0, -v[2], v[1], v[2], 0, -v[0], -v[1], v[0], 0)
    k = np.matrix(vXStr)
    rot=(I + k + np.dot(k,k) * ((1 -c)/(s**2)))
    return rot

dictionary={"Ac":2.15,"Al":1.21,"Am":1.8,"Sb":1.39,"Ar":1.51,"As":1.21,"At":1.21,"Ba":2.15,"Bk":1.54,"Be":0.96,"Bi":1.48,"Bh":1.5,"B":0.83,"Br":1.21,
            "Cd":1.54,"Cs":2.44,"Ca":1.76,"Cf":1.83,"C":0.68,"Ce":2.04,"Cl":0.99,"Cr":1.39,"Co":1.26,"Cu":1.32,"Cm":1.69,"Ds":1.5,"Db":1.5,"Dy":1.92,
            "Es":1.5,"Er":1.89,"Eu":1.98,"Fm":1.5,"F":0.64,"Fr":2.6,"Gd":1.96,"Ga":1.22,"Ge":1.17,"Au":1.36,"Hf":1.75,"Hs":1.5,"He":1.5,"Ho":1.92,
            "H":0.23,"In":1.42,"I":1.4,"Ir":1.41,"Fe":1.52,"Kr":1.5,"La":2.07,"Lr":1.5,"Pb":1.46,"Li":1.28,"Lu":1.87,"Mg":1.41,"Mn":1.61,"Mt":1.5,
            "Md":1.5,"Hg":1.32,"Mo":1.54,"Nd":2.01,"Ne":1.5,"Np":1.9,"Ni":1.24,"Nb":1.64,"N":0.68,"No":1.5,"Os":1.44,"O":0.68,"Pd":1.39,"P":1.05,
            "Pt":1.36,"Pu":1.87,"Po":1.4,"K":2.03,"Pr":2.03,"Pm":1.99,"Pa":2,"Ra":2.21,"Rn":1.5,"Re":1.51,"Rh":1.42,"Rb":2.2,"Ru":1.46,"Rf":1.5,
            "Sm":1.98,"Sc":1.7,"Sg":1.5,"Se":1.22,"Si":1.2,"Ag":1.45,"Na":1.66,"Sr":1.95,"S":1.02,"Ta":1.7,"Tc":1.47,"Te":1.47,"Tb":1.94,"Tl":1.45,
            "Th":2.06,"Tm":1.9,"Sn":1.39,"Ti":1.6,"W":1.62,"U":1.96,"V":1.53,"Xe":1.5,"Yb":1.87,"Y":1.9,"Zn":1.22,"Zr":1.75}






path1=os.getcwd()+"/uploads/"+sys.argv[1]
os.chdir(path1) 
os.system("chmod 777 *")
#os.chdir("/var/www/html/uploads")

with open('choice.txt') as choice:
    choice_pdb="".join(choice.readline().split())
    choice_lig="".join(choice.readline().split())  

with open('contain.txt') as contain:
    filename1="".join(contain.readline().split())
    filename2="".join(contain.readline().split())
    

with open(filename1) as pdb:
    pdb_arxeio=[]
    pdb_lines=pdb.readlines()


    for i in pdb_lines:
        if i.startswith('HETATM') or i.startswith('ATOM'):
            pdb_arxeio.append("".join(i).split())

pdb_arxeio=pd.DataFrame(pdb_arxeio)
pdb_coords=np.array(pdb_arxeio.iloc[:,3:6],dtype=float)


atoma_pdb=[]
for i in range(len(pdb_arxeio)):
    if pdb_arxeio.iloc[i,2] not in atoma_pdb:
        atoma_pdb.append(pdb_arxeio.iloc[i,2])
        
for i in range(len(atoma_pdb)):
    if choice_pdb==atoma_pdb[i]:
        pdb_atomo_allilepidrashs=i
        
############################################################################################################################
################## ZHTAW AP TON XRHSTH NA MOU PEI ME POIO STOIXEIO TOU KRYSTALOU THELW NA GINEI ALLILEPIDRASH ##############
############################################################################################################################

if len(atoma_pdb)>=2:
    while True:
        #print("\nTa stoixeia poy yparxoyn ston krystallo einai ta exhs: \n")
        #for i,j in enumerate(atoma_pdb):
            #print('{} ==> {}'.format(i+1,j))
        try:
            #pdb_atomo_allilepidrashs= input ("Pes mou me poio atomo tou pdb arxeiou theleis na allilepidrasei me to ligand: ") 
            #pdb_atomo_allilepidrashs=int(pdb_atomo_allilepidrashs)-1
            pdb_coords_allilep=[]
            if pdb_atomo_allilepidrashs not in range(len(atoma_pdb)):
                print("\n \n *******O arithmos pou dwsate dn yparxei sthn lista*******\n")
                continue
            else:
                print("Ypologizw ta stoixeia tou {} gyrw apo ton krystallo.......".format(atoma_pdb[pdb_atomo_allilepidrashs]))
                for i in range(len(pdb_arxeio)):
                    if pdb_arxeio.iloc[i,2] == atoma_pdb[pdb_atomo_allilepidrashs]:
                        pdb_coords_allilep.append(pdb_arxeio.iloc[i,3:6])
            break
        except ValueError:
            print("\n \n *******Thelw arithmo apo thn lista!!! *******\n")
            continue
        
else:
    print("Ypologizw ta stoixeia tou {} gyrw apo ton krystallo.......".format(atoma_pdb[0]))
    pdb_coords_allilep=[]
    pdb_atomo_allilepidrashs=0
    for i in range(len(pdb_arxeio)):
        pdb_coords_allilep.append(pdb_arxeio.iloc[i,3:6])
        

############################################################################################################################
############################################################################################################################
        

############################################################################################################################
    
hull=ConvexHull(pdb_coords)
shmeia_convex=hull.simplices

trigwna=[]
for i in range(shmeia_convex.shape[0]): 
    temparray = []
    for j in range(3):
        temparray.append(pdb_coords[shmeia_convex[i][j]])
    trigwna.append(temparray)





#ΒΡΙΣΚΩ ΤΑ ΔΙΑΝΥΣΜΑΤΑ ΤΟΥ ΤΡΙΓΩΝΟΥ,ΤΙΣ ΑΠΟΣΤΑΣΕΙΣ ΑΒ ΚΑΙ ΑC ΤΟΥ ΤΡΙΓΩΝΟΥ

emvadon=[]

for i in range(len(trigwna)):
    trigwno=np.array(trigwna[i])
    ab_simplices=(trigwno[1] - trigwno[0])
    ac_simplices=(trigwno[2] - trigwno[0])
    kathetos1=(np.cross(ab_simplices, ac_simplices))
    emvadon.append(0.5*(np.linalg.norm(kathetos1)))

emvadon1=[]

for i in range(len(trigwna)):
    trigwno1=np.array(trigwna[i])*0.1
    ab_simplices1=(trigwno1[1] - trigwno1[0])
    ac_simplices1=(trigwno1[2] - trigwno1[0])
    kathetos2=(np.cross(ab_simplices1, ac_simplices1))
    emvadon1.append(0.5*(np.linalg.norm(kathetos2)))



#################################################################################################




#################################################################################################
########################  ΚΑΤΑΝΟΜΗ ΤΩΝ LIGANDS ΓΥΡΩ ΑΠ ΤΟΝ ΚΡΥΣΤΑΛΛΟ   ##########################
#################################################################################################

#emvadon=sorted(emvadon)


synolo_ligands=[]
for i in range(len(emvadon)):
    synolo_ligands.append((emvadon[i]/1)) #TODO PYKNOTHTA

emvadon_synolo=np.sum(emvadon)

#xxx=np.sum(synolo_ligands)

with open(filename2) as lig:
   lig_lines=lig.readlines()
   for i in range(len(lig_lines)):
       if lig_lines[i].startswith('@<TRIPOS>ATOM'):
           arxi=i+1
       if lig_lines[i].startswith('@<TRIPOS>BOND'):
          mesh=i
       if lig_lines[i].startswith('@<TRIPOS>SUBSTRUCTURE'):
           telos=i
ligand_file= "".join(lig_lines[arxi:mesh])
ligand_file_bond= "".join(lig_lines[mesh+1:telos])
ligand_file_pd = pd.DataFrame([x.split() for x in ligand_file.split('\n')])
ligand_file_bond=pd.DataFrame([x.split() for x in ligand_file_bond.split('\n')])
ligand_file_pd=ligand_file_pd.drop(ligand_file_pd.index[-1])
ligand_file_bond=ligand_file_bond.drop(ligand_file_bond.index[-1])
ligand_coords_arxiko=np.array(ligand_file_pd.iloc[:,2:5],dtype=float)
ligand_file_bond=np.array(ligand_file_bond.iloc[:,1:3],dtype=int)
ligand_stoixeia=ligand_file_pd.iloc[:,1]





for i in range(len(ligand_file_pd)):
    if choice_lig == ligand_file_pd.iloc[i,1]:
        epilogh_test=i









while True:
    #for i in range(len(ligand_coords_arxiko)):
        #print('{} ==> {}'.format(ligand_file_pd.iloc[i,0],ligand_file_pd.iloc[i,1]))
    #epilogh_test=input("Epelexe to atomo tou ligand me to opoio o krystalos theleis na allilepidrasei: ")
    try:
        if 0<=int(epilogh_test)<=len(ligand_coords_arxiko):
            epilogh=int(epilogh_test)
            break
        else:
            print('\n')
            print("Dialexe kati apo ta parakatw: ")
            print('\n')
            continue
    except ValueError:
        print('\n')
        print("Xanaprospathise!!! Auth thn fora dwsmou arithmo...")
        print('\n')
        continue

   

ligand_coords_teliko=ligand_coords_arxiko-ligand_coords_arxiko[epilogh]   # ΦΕΡΝΩ ΤΟ LIGAND ΣΤΟ (0,0)


ligand_norm=[]
for i in range(len(ligand_coords_teliko)):
    ligand_norm.append(np.linalg.norm(ligand_coords_teliko[i]))

vector_y=ligand_coords_teliko[ligand_norm.index(max(ligand_norm))]-ligand_coords_teliko[epilogh] # VECTOR Y ΓΙΑ ΜΕΤΑ


gwnia_gia_metrisi=rot_matrix([1,0,1],vector_y)

metrisi=[]
for i in range(len(ligand_coords_teliko)):
    metrisi.append(ligand_coords_teliko[i]*gwnia_gia_metrisi)
metrisi1=np.stack(metrisi,axis=0)
apostash_y_temp=(np.linalg.norm((max(metrisi1[:,1])-min(metrisi1[:,1])))*0.1)  #SE NANOMETRA
apostash_z_temp=(np.linalg.norm((max(metrisi1[:,2])-min(metrisi1[:,2])))*0.1)  #SE NANOMETRA
if apostash_z_temp >= apostash_y_temp:
    apostash_y_temp=apostash_z_temp
apostash_y_aktina=(apostash_y_temp/2)    
apostash_y_diametros=((np.pi)*((apostash_y_aktina)**2)) #KYKLIKO EMVADON

emvadon_synolo1=np.sum(emvadon1)
num_of_graft=(emvadon_synolo1/apostash_y_diametros)


#graft_test=((emvadon_synolo*0.1)/apostash_y)

graft='{:.2f}'.format(num_of_graft/(emvadon_synolo1))

length1=(''.join(x for x in ligand_file_pd.iloc[epilogh,1] if x.isalpha())).capitalize()
length2=(''.join(x for x in atoma_pdb[pdb_atomo_allilepidrashs] if x.isalpha())).capitalize()

len_dict=float("{:}".format(round((dictionary[length1]+dictionary[length2])*0.1,2)))
#graft=float(graft)
#len_dict=float(len_dict)

zzz2=open('graftlen.txt','w')
zzz2.write("{:}\n".format(graft))
zzz2.write("{:}\n".format(len_dict))
zzz2.close()
#os.chdir("../")

##ΕΛΕΓΧΩ ΑΝ ΜΕΣΑ ΣΤΟ LIGAND ΥΠΑΡΧΕΙ ΤΟ ΣΤΟΙΧΕΙΟ ΗΔΗ, ΑΝ ΝΑΙ,,ΔΕΝ ΞΑΝΑΖΗΤΑΩ sigma και epsilon!!!###  
atoma_pdb_del=[]
for i in range(len(ligand_file_pd)):
    for j in range(len(atoma_pdb)):
        if ligand_file_pd.iloc[i,1][0]==atoma_pdb[j]:
            atoma_pdb_del.append(j)
        
atoma_pdb_del.sort(reverse=True)
atoma_pdb_del = list(dict.fromkeys(atoma_pdb_del))
for i in range(len(atoma_pdb_del)):
    del atoma_pdb[atoma_pdb_del[i]]
    
zzz3=open('graftlen.txt','a')
for i in range(len(atoma_pdb)):
    zzz3.write(str(atoma_pdb[i])+'\n')
zzz3.close()  
os.chdir("../../")
#########################################
  
# =============================================================================
# sigma=[]
# epsilon=[]
# 
# while True:
#     try:
#         for i,j in enumerate(atoma_pdb):
#             sigma1=input('Dwse me mou to sigma gia to \'{}\': '.format(j))
#             epsilon1=input('Dwse me mou to epsilon gia to \'{}\': '.format(j))
#             sigma1=float(sigma1)
#             epsilon1=float(epsilon1)
#             sigma.append(sigma1)
#             epsilon.append(epsilon1)
#             print('\nTo \'sigma kai epsilon\' gia to \'{}\' einai egkyroi arithmoi!!! Synexizw.....'.format(j))
#         break
#     except ValueError:
#         print("\n \n *******Kati den mou edwses swsta!!! Dwsmou pali \'sigma kai epsilon\' gia to \'{}\' *******\n".format(j))
#         continue  
# 
# zzz3=open('graftlen.txt','w')
# zzz3.write(str(graft)+'\n')
# zzz3.write(str(len_dict)+'\n')
# zzz3.close()
# os.chdir("../")
# =============================================================================
