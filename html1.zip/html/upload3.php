<?php
session_start();
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$pdbarxeio = file("uploads/".session_id()."/graftlen.txt");
echo $pdbarxeio[0];
?>
