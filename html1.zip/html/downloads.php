
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>NASTOS web-tool</title>
	<style>
	.center {
	  margin: 0;
	  position: absolute;
	  top: 50%;
	  left: 50%;
	  -ms-transform: translate(-50%, -50%);
	  transform: translate(-50%, -50%);
	}
</style>
<link rel="stylesheet" href="css/nastos_1.css">
</head>
<body>
<h1 class="display-3"> The web-sever for automatic creation of functionalized nanoparticles </h3> 
<p>This tool constructs functionalized nanoparticles. Feel free to use it... </p>
</br></br></br>
<div class="login1">
    <input class='btn btn-primary btn-lg' type="submit" value="Download .pdb file" onclick="location.href='download_pdb.php'">
    <input class='btn btn-primary btn-lg' type="submit" value="Download .gro file" onclick="location.href='download_gro.php'">
    <input class='btn btn-primary btn-lg' type="submit" value="Download .top file" onclick="location.href='download_top.php'"><br><br><br><br>
</div>
<div class="return">
     <input class="return" type="submit" value="return to home page" onclick="location.href='funserver.html'">
</div>
<script src="js/nastos.js"></script> 
<script></script> 

</body>
</html>
