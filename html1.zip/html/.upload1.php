<?php
session_start();
session_regenerate_id();
$id = "uploads/".session_id();
$del_help=$id."/help.txt";
$del_ok=$id."/ok.html";

if ((file_exists($del_help))){
    unlink($del_help);
}
if ((file_exists($del_ok))){
    unlink($del_ok);
}
mkdir($id , 0700);
$target_dir = "uploads/". session_id() ."/";
$target_file1 =  basename($_FILES["fileToUpload1"]["name"]);
$target_file1 = iconv('UTF-8', 'ASCII//TRANSLIT', $target_file1);
$target_file1 = $target_dir .preg_replace('/[^A-Za-z0-9-.]/', 'a', $target_file1);


$target_file2 = basename($_FILES["fileToUpload2"]["name"]);
$target_file2 = iconv('UTF-8', 'ASCII//TRANSLIT', $target_file2);
$target_file2 = $target_dir .preg_replace('/[^A-Za-z0-9-.]/', 'a', $target_file2);


$uploadOk1 = 1;
$uploadOk2 = 1;

$fileFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
$fileFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
//$fileFileType1=substr($target_file1, -3));
//$fileFileType2=strolower(substr($target_file2, -4));


// Check if files already exists


if ((file_exists($target_file1)) or  (file_exists($target_file2))){
    echo "Sorry, one of the ".$fileFileType1. " or the ".$fileFileType2." that you are trying to upload,already exists.";
    $uploadOk1 = 0;
	$uploadOk2 = 0;
}

// Check files size
if (($_FILES["fileToUpload1"]["size"] > 500000) or ($_FILES["fileToUpload2"]["size"] > 500000)) {
    echo "Sorry, one of your file is too large, check them again.";
    $uploadOk1 = 0;
	$uploadOk2 = 0;

}


// Allow certain file fomats
if($fileFileType1 != "pdb" ) {
    echo "<br>You were tried to upload a .".$fileFileType1." file as nanocrystal. Sorry, only .pdb files are allowed.";
    $uploadOk1 = 0;
	$uploadOk2 = 0;

}

if($fileFileType2 != "mol2" ) {
    echo "<br>You were tried to upload a .".$fileFileType2." file as ligand. Sorry, only .mol2 files are allowed.";
    $uploadOk1 = 0;
	$uploadOk2 = 0;
	
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk1==0 or  $uploadOk2 == 0){
    echo "<br>For security reasons, your files were NOT uploaded!!";
	echo "<br>Please go back and try again...";
// if everything is ok, try to upload file
} else {
    if ((move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_file1)) and (move_uploaded_file($_FILES["fileToUpload2"]["tmp_name"], $target_file2))){
        echo "The files have been uploaded.";

		$name1=basename($_FILES["fileToUpload1"]["name"]);
		$name1 = iconv('UTF-8', 'ASCII//TRANSLIT', $name1);
		$name1 = preg_replace('/[^A-Za-z0-9-.]/', 'a', $name1);
		$name2=basename($_FILES["fileToUpload2"]["name"]);
		$name2 = iconv('UTF-8', 'ASCII//TRANSLIT', $name2);
		$name2 = preg_replace('/[^A-Za-z0-9-.]/', 'a', $name2);

		$_SESSION['name1']= substr($name1, 0, -4);
		$_SESSION['name2']= substr($name2, 0, -5);


		$conitain = fopen("uploads/".session_id()."/contain.txt", "w");
		fwrite($conitain, ($name1));
		fwrite($conitain, "\n");
		fwrite($conitain, ($name2));

                $command = escapeshellcmd('python3 .test.py '.session_id());
                $output = shell_exec($command);
                echo $output;
                //echo shell_exec("/var/www/html/test.py 2>&1");

                header('Location: parameters.php');
                exit;
		



    } else {
        echo "<br>Sorry, there was an error uploading your files.";
    }
}


?>
