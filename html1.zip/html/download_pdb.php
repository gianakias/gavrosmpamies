<?php
    session_start();
    $path1 = "uploads/".session_id()."/";
    $test_file = $path1."help.txt";
    $help_lines = file($test_file);
    $path =$path1.$help_lines[0]."/";
    $name = basename(glob($path."*+*.pdb", GLOB_BRACE)[0]);
    $file = $path.$name;
    $type = filetype($file);
    if(!file_exists($file)) die("The file doesn't seem to exist!!!!");
    // Send file headers
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header("Content-type: $type");
    header("Content-Disposition: attachment;filename=$name");
    header("Content-Transfer-Encoding: binary");
    header('Pragma: no-cache');
    header('Expires: 0');
    // Send the file contents.
    set_time_limit(0);
    readfile($file);
    

?>
