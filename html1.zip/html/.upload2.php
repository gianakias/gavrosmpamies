<?php
$firstname = $_POST['pdb'];
$lastname = $_POST['mol'];
$session_id_1 =$_POST['ses'];
if ((!empty($firstname)) and (!empty($lastname))){
	$pdbarxeio = fopen ("uploads/".$session_id_1."/choice.txt","w");
	$mydata=$firstname."\n".$lastname;
	fwrite ($pdbarxeio, $mydata);
	fclose ($pdbarxeio);
	$command = escapeshellcmd('python3 .test1.py '.$session_id_1);
	$output = shell_exec($command);
	//$graft_length = fopen("uploads/graftlen.txt","r");
	$lines = file("uploads/".$session_id_1."/graftlen.txt");//file in to an array
	$lines1 = implode(" ",$lines);
	echo $lines1;
}else{
    echo "****** Select both nanocrystal and ligand element, and WAIT until your preferences are loaded ******";
}
?>
