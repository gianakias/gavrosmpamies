#!/usr/bin/env python
import os,sys
import numpy as np
import json
import ase
import math
import pandas as pd
from scipy.spatial import ConvexHull
from os.path import join
from ase.data import atomic_numbers, atomic_names, atomic_masses, covalent_radii

##################################################################################################

##################################################################################################
path=os.getcwd()+"/uploads/"+sys.argv[1]
os.chdir(path)
os.system("chmod 777 *")
with open('contain.txt') as info:
    pdb_info_name=info.readline().strip()
    ligand_info_name=info.readline().strip()
file_name =pdb_info_name.split('.')[0]+'_and_'+ligand_info_name.split('.')[0]
fakelos = os.path.join(path, file_name) 
os.mkdir(fakelos)
os.system('mv * /'+fakelos)
os.chdir(fakelos)


with open('parameters.txt') as parameters:
    parameter=parameters.readline().split(' and ')
    pdb_choice_par = parameter[0]
    lig_choice_par = parameter[1]
    graft_choice_par = parameter[2]
    check_choice_par = parameter[3]
    no_bond_choice_par = parameter[4]
    bond_choice_par = parameter[5]
    sigma_choice_par = parameter[6]
    epsilon_choice_par = parameter[7]
    
os.system('cp '+ pdb_info_name+' '+ ligand_info_name+' ../')
os.chdir(path)

##################################################################################################

##################################################################################################



def rot_matrix(x,y):
    #curve_vec_1=[0.043477,0.036412,0.998391]
    curve_vec_1=x
    curve_vec_2=y
    a,b = (curve_vec_1/ np.linalg.norm(curve_vec_1)).reshape(3), (curve_vec_2/ np.linalg.norm(curve_vec_2)).reshape(3)
    v = np.cross(a,b)
    c = np.dot(a,b)
    s = np.linalg.norm(v)
    I = np.identity(3)
    vXStr = '{} {} {}; {} {} {}; {} {} {}'.format(0, -v[2], v[1], v[2], 0, -v[0], -v[1], v[0], 0)
    k = np.matrix(vXStr)
    rot=(I + k + np.dot(k,k) * ((1 -c)/(s**2)))
    return rot


dictionary={"Ac":2.15,"Al":1.21,"Am":1.8,"Sb":1.39,"Ar":1.51,"As":1.21,"At":1.21,"Ba":2.15,"Bk":1.54,"Be":0.96,"Bi":1.48,"Bh":1.5,"B":0.83,"Br":1.21,
            "Cd":1.54,"Cs":2.44,"Ca":1.76,"Cf":1.83,"C":0.68,"Ce":2.04,"Cl":0.99,"Cr":1.39,"Co":1.26,"Cu":1.32,"Cm":1.69,"Ds":1.5,"Db":1.5,"Dy":1.92,
            "Es":1.5,"Er":1.89,"Eu":1.98,"Fm":1.5,"F":0.64,"Fr":2.6,"Gd":1.96,"Ga":1.22,"Ge":1.17,"Au":1.36,"Hf":1.75,"Hs":1.5,"He":1.5,"Ho":1.92,
            "H":0.23,"In":1.42,"I":1.4,"Ir":1.41,"Fe":1.52,"Kr":1.5,"La":2.07,"Lr":1.5,"Pb":1.46,"Li":1.28,"Lu":1.87,"Mg":1.41,"Mn":1.61,"Mt":1.5,
            "Md":1.5,"Hg":1.32,"Mo":1.54,"Nd":2.01,"Ne":1.5,"Np":1.9,"Ni":1.24,"Nb":1.64,"N":0.68,"No":1.5,"Os":1.44,"O":0.68,"Pd":1.39,"P":1.05,
            "Pt":1.36,"Pu":1.87,"Po":1.4,"K":2.03,"Pr":2.03,"Pm":1.99,"Pa":2,"Ra":2.21,"Rn":1.5,"Re":1.51,"Rh":1.42,"Rb":2.2,"Ru":1.46,"Rf":1.5,
            "Sm":1.98,"Sc":1.7,"Sg":1.5,"Se":1.22,"Si":1.2,"Ag":1.45,"Na":1.66,"Sr":1.95,"S":1.02,"Ta":1.7,"Tc":1.47,"Te":1.47,"Tb":1.94,"Tl":1.45,
            "Th":2.06,"Tm":1.9,"Sn":1.39,"Ti":1.6,"W":1.62,"U":1.96,"V":1.53,"Xe":1.5,"Yb":1.87,"Y":1.9,"Zn":1.22,"Zr":1.75}




################### ΑΝΟΙΓΩ ΤΟ LIGAND ######################

with open(ligand_info_name) as lig:
   lig_lines=lig.readlines()
   for i in range(len(lig_lines)):
       if lig_lines[i].startswith('@<TRIPOS>ATOM'):
           arxi=i+1
       if lig_lines[i].startswith('@<TRIPOS>BOND'):
          mesh=i
       if lig_lines[i].startswith('@<TRIPOS>SUBSTRUCTURE'):
           telos=i
ligand_file= "".join(lig_lines[arxi:mesh])
ligand_file_bond= "".join(lig_lines[mesh+1:telos])
ligand_file_pd = pd.DataFrame([x.split() for x in ligand_file.split('\n')])
ligand_file_bond=pd.DataFrame([x.split() for x in ligand_file_bond.split('\n')])
ligand_file_pd=ligand_file_pd.drop(ligand_file_pd.index[-1])
ligand_file_bond=ligand_file_bond.drop(ligand_file_bond.index[-1])
ligand_coords_arxiko=np.array(ligand_file_pd.iloc[:,2:5],dtype=float)
ligand_file_bond=np.array(ligand_file_bond.iloc[:,1:3],dtype=int)
ligand_stoixeia=ligand_file_pd.iloc[:,1]

ligand_st=[]
for i in ligand_stoixeia:
   ligand_st.append((''.join(x for x in i if x.isalpha())))
ligand_st=np.unique(ligand_st)
ligand_st=np.array(ligand_st)
ligand_st=ligand_st.tolist()
ligand_st=' '.join(ligand_st)


connect=[]
connect_1=[]
for i in range(len(ligand_file_bond)+1):
    for j in range(len(ligand_file_bond)):
        if i == ligand_file_bond[j,0]:
            connect.append(ligand_file_bond[j,1])
        elif i==ligand_file_bond[j,1]:
            connect.append(ligand_file_bond[j,0])
    if i ==0:
        continue
    connect_1.append([i,connect])
    connect=[]


connect_2=[]
for i in range(len(connect_1)):
    connect_2.append(np.hstack(connect_1[i]))        


connect_2=pd.DataFrame(connect_2)

################ DIORTHWSH CONNECT ###########################

if len(connect_1)!=len(ligand_coords_arxiko):
    connect_1_diorthosi_temp_2=[]
    for i in range(len(connect_1)):
        if connect_1[i][1] !=[]:
            connect_1_diorthosi_temp_2.append(connect_1[i])
    connect_1=sorted(connect_1_diorthosi_temp_2,key=lambda x:x[0])
else:
    connect_1_diorthosi_temp_1=[]
    for i in range(len(connect_1)):
        if connect_1[i][1] !=[]:
            connect_1_diorthosi_temp_1.append(connect_1[i])
    connect_1=sorted(connect_1_diorthosi_temp_1,key=lambda x:x[0])





#################### ΕΠΙΛΕΓΩ ΤΟ ΣΤΟΙΧΕΙΟ ΠΟΥ ΘΑ ΣΥΝΔΕΘΕΙ ################################


while True:
    for i in range(len(ligand_coords_arxiko)):
        if ligand_file_pd.iloc[i,1]==lig_choice_par:
            epilogh_test =str(i+1)
        #print('{} ==> {}'.format(ligand_file_pd.iloc[i,0],ligand_file_pd.iloc[i,1]))
    #epilogh_test=input("Epelexe to atomo tou ligand me to opoio o krystalos theleis na allilepidrasei: ")
    try:
        if 1<=int(epilogh_test)<=len(ligand_coords_arxiko):
            epilogh=int(epilogh_test)-1
            break
        else:
            print('\n')
            print("Dialexe kati apo ta parakatw: ")
            print('\n')
            continue
    except ValueError:
        print('\n')
        print("Xanaprospathise!!! Auth thn fora dwsmou arithmo...")
        print('\n')
        continue

   

ligand_coords_teliko=ligand_coords_arxiko-ligand_coords_arxiko[epilogh]   # ΦΕΡΝΩ ΤΟ LIGAND ΣΤΟ (0,0)


ligand_norm=[]
for i in range(len(ligand_coords_teliko)):
    ligand_norm.append(np.linalg.norm(ligand_coords_teliko[i]))

vector_y=ligand_coords_teliko[ligand_norm.index(max(ligand_norm))]-ligand_coords_teliko[epilogh] # VECTOR Y ΓΙΑ ΜΕΤΑ


gwnia_gia_metrisi=rot_matrix([1,0,1],vector_y)

metrisi=[]
for i in range(len(ligand_coords_teliko)):
    metrisi.append(ligand_coords_teliko[i]*gwnia_gia_metrisi)
metrisi1=np.stack(metrisi,axis=0)
apostash_y_temp=(np.linalg.norm((max(metrisi1[:,1])-min(metrisi1[:,1])))*0.1)  #SE NANOMETRA
apostash_z_temp=(np.linalg.norm((max(metrisi1[:,2])-min(metrisi1[:,2])))*0.1)  #SE NANOMETRA
if apostash_z_temp >= apostash_y_temp:
    apostash_y_temp=apostash_z_temp
apostash_y_aktina=(apostash_y_temp/2)    
apostash_y_diametros=((np.pi)*((apostash_y_aktina)**2)) #KYKLIKO EMVADON


    
    
    




################### ΑΝΟΙΓΩ ΤΟN ΚΡΥΣΤΑΛΛΟ ######################



with open(pdb_info_name) as pdb:
    pdb_arxeio=[]
    pdb_lines=pdb.readlines()


    for i in pdb_lines:
        if i.startswith('HETATM') or i.startswith('ATOM'):
            pdb_arxeio.append("".join(i).split())

pdb_arxeio=pd.DataFrame(pdb_arxeio)
pdb_coords=np.array(pdb_arxeio.iloc[:,3:6],dtype=float)


atoma_pdb=[]
for i in range(len(pdb_arxeio)):
    if pdb_arxeio.iloc[i,2] not in atoma_pdb:
        atoma_pdb.append(pdb_arxeio.iloc[i,2])
        
        
        
        
        
        

############################################################################################################################
################## ZHTAW AP TON XRHSTH NA MOU PEI ME POIO STOIXEIO TOU KRYSTALOU THELW NA GINEI ALLILEPIDRASH ##############
############################################################################################################################

if len(atoma_pdb)>=2:
    while True:
        #print("\nTa stoixeia poy yparxoyn ston krystallo einai ta exhs: \n")
        #for i,j in enumerate(atoma_pdb):
        #    print('{} ==> {}'.format(i+1,j))
        try:
            for i in range(len(atoma_pdb)):
                if atoma_pdb[i]==pdb_choice_par:
                    pdb_atomo_allilepidrashs=i+1
            #pdb_atomo_allilepidrashs= input ("Pes mou me poio atomo tou pdb arxeiou theleis na allilepidrasei me to ligand: ") 
            pdb_atomo_allilepidrashs=int(pdb_atomo_allilepidrashs)-1
            pdb_coords_allilep=[]
            if pdb_atomo_allilepidrashs not in range(len(atoma_pdb)):
                print("\n \n *******O arithmos pou dwsate dn yparxei sthn lista*******\n")
                continue
            else:
                #print("Ypologizw ta stoixeia tou {} gyrw apo ton krystallo.......".format(atoma_pdb[pdb_atomo_allilepidrashs]))
                for i in range(len(pdb_arxeio)):
                    if pdb_arxeio.iloc[i,2] == atoma_pdb[pdb_atomo_allilepidrashs]:
                        pdb_coords_allilep.append(pdb_arxeio.iloc[i,3:6])
            break
        except ValueError:
            print("\n \n *******Thelw arithmo apo thn lista!!! *******\n")
            continue
        
else:
    print("Ypologizw ta stoixeia tou {} gyrw apo ton krystallo.......".format(atoma_pdb[0]))
    pdb_coords_allilep=[]
    pdb_atomo_allilepidrashs=0
    for i in range(len(pdb_arxeio)):
        pdb_coords_allilep.append(pdb_arxeio.iloc[i,3:6])

############################################################################################################################
############################################################################################################################
        

############################################################################################################################
    
hull=ConvexHull(pdb_coords)
shmeia_convex=hull.simplices

trigwna=[]
for i in range(shmeia_convex.shape[0]): 
    temparray = []
    for j in range(3):
        temparray.append(pdb_coords[shmeia_convex[i][j]])
    trigwna.append(temparray)





#ΒΡΙΣΚΩ ΤΑ ΔΙΑΝΥΣΜΑΤΑ ΤΟΥ ΤΡΙΓΩΝΟΥ,ΤΙΣ ΑΠΟΣΤΑΣΕΙΣ ΑΒ ΚΑΙ ΑC ΤΟΥ ΤΡΙΓΩΝΟΥ

emvadon=[]

for i in range(len(trigwna)):
    trigwno=np.array(trigwna[i])
    ab_simplices=(trigwno[1] - trigwno[0])
    ac_simplices=(trigwno[2] - trigwno[0])
    kathetos1=(np.cross(ab_simplices, ac_simplices))
    emvadon.append(0.5*(np.linalg.norm(kathetos1)))


emvadon1=[]

for i in range(len(trigwna)):
    trigwno1=np.array(trigwna[i])*0.1
    ab_simplices1=(trigwno1[1] - trigwno1[0])
    ac_simplices1=(trigwno1[2] - trigwno1[0])
    kathetos2=(np.cross(ab_simplices1, ac_simplices1))
    emvadon1.append(0.5*(np.linalg.norm(kathetos2)))



#################################################################################################


#################################################################################################
########################  ΚΑΤΑΝΟΜΗ ΤΩΝ LIGANDS ΓΥΡΩ ΑΠ ΤΟΝ ΚΡΥΣΤΑΛΛΟ   ##########################
#################################################################################################

#emvadon=sorted(emvadon)


synolo_ligands=[]
for i in range(len(emvadon)):
    synolo_ligands.append((emvadon[i]/1)) #TODO PYKNOTHTA




n=int(np.sum(synolo_ligands))


emvadon_synolo=np.sum(emvadon)

probabilities=(emvadon/emvadon_synolo)

weighted_random=np.random.choice(range(len(emvadon)),size=n,p=probabilities)


v1_xyz=[]
v2_xyz=[]
v3_xyz=[]

for i in range(len(weighted_random)):
    v1_xyz.append(trigwna[weighted_random[i]][0])
    v2_xyz.append(trigwna[weighted_random[i]][1])
    v3_xyz.append(trigwna[weighted_random[i]][2])
  



u=np.random.rand(n,1)
v=np.random.rand(n,1)
is_a_problem = u+v > 1

u[is_a_problem]=1-u[is_a_problem]
v[is_a_problem]=1-v[is_a_problem]

w=1-(u + v)
   

result_xyz=(v1_xyz*u)+(v2_xyz*v)+(w*v3_xyz)

result_xyz_test=np.array(result_xyz,dtype=float)
pdb_coords_allilep_test=np.array(pdb_coords_allilep,dtype=float)



#TRAVAEI TA SHMEIA STO PIO KONTINO ATOMO POU VRISKEI
kentro_ligand_temp=[]
min_dis_allilep_temp2=[]
min_dis_allilep_temp1=[]

for i in range(len(result_xyz)):
    for j in range(len(pdb_coords_allilep)):
        min_dis_allilep_temp1.append(np.linalg.norm(result_xyz_test[i]-pdb_coords_allilep_test[j]))
    if min_dis_allilep_temp1.index(min(min_dis_allilep_temp1)) not in min_dis_allilep_temp2:
        min_dis_allilep_temp2.append(min_dis_allilep_temp1.index(min(min_dis_allilep_temp1)))
        kentro_ligand_temp.append(pdb_coords_allilep[min_dis_allilep_temp1.index(min(min_dis_allilep_temp1))])
        min_dis_allilep_temp1=[]
    min_dis_allilep_temp1=[]
    


print("\nYpologismos stoixeiwn tou '{}' epityxis".format(atoma_pdb[pdb_atomo_allilepidrashs]))

kentro_ligand_test=[]
kentro_ligand_temp=np.array(kentro_ligand_temp,dtype=float)

testaki=[]
for i in (range(len(kentro_ligand_temp))):
    testaki.append(kentro_ligand_temp[i]-kentro_ligand_temp[0])

testaki1=abs(np.mean(testaki))/20
testaki11=(np.pi)*((testaki1)**2)

if apostash_y_diametros<testaki11:
    apostash_y_diametros=testaki11
#################################################################################################
################### Κοιτάω να μην κάνουν bond με βαση το Grafting Density #######################
#################################################################################################    
while True:
    emvadon_synolo1=np.sum(emvadon1)
    num_of_graft=(emvadon_synolo1/apostash_y_diametros)
    print("\nTo megisto density pou mporeis na dwseis einai {:.2f} chains/nm^2. An dwseis perissotero diakindineueis ta ligands na pesei to ena panw sto allo!\n".format(num_of_graft/(emvadon_synolo1)))
    #graft2 = input ("Grafting Density se chains/ynm^2: ") 
    graft2 = graft_choice_par
    graft2 = float (graft2)
    try:
        if graft2 >0:
            graft1=graft2*emvadon_synolo1
            graft0=emvadon_synolo1/graft1
            graft=((((graft0/(np.pi))**(0.5))*2))*10 #SE Amstrong
            break
        else:
            print("\n \n*******Den yparxei Grafting Density...*******\n \n")
            continue
    except ValueError:
        print("\n \n*******Thelw arithmo...*******\n \n")
        continue



kentro_ligand_test=[]
kentro_ligand_temp=np.array(kentro_ligand_temp,dtype=float)
graft_test=pd.DataFrame(kentro_ligand_temp)
graft_test1=pd.DataFrame(kentro_ligand_temp)

print ("\nGinontai ypologismoi  me vasi tou Grafting Density ...\n")
for i in range(len(graft_test)):
    if i not in kentro_ligand_test:
        for j in range(len(graft_test)):
            if 0< np.linalg.norm(graft_test.iloc[i]-graft_test1.iloc[j])<=graft:
                kentro_ligand_test.append(j)
    else:
        pass              

print ("\nOi ypologismoi oloklirwthikan!\n")


kentro_ligand_1=np.unique(kentro_ligand_test)
kentro_ligand_2=graft_test.drop(kentro_ligand_1)


kentro_ligand_allilepidrasi7=np.array(kentro_ligand_2)
kentro_ligand_allilepidrasi=list(kentro_ligand_allilepidrasi7)



#print("Γύρω από τον κρύσταλο θα τοποθετηθούν {} ligands".format(len(kentro_ligand_allilepidrasi)))

#################################################################################################
################### ΡΩΤΑΩ ΤΟΝ ΧΡΗΣΤΗ ΑΝ ΘΕΛΕΙ ΝΑ ΚΑΝΕΙ ΔΕΣΜΟ ####################################
#################################################################################################


# =============================================================================
# desmos=True
# if desmos == True:        
#     while True:
#         #print("\n!!! Hint !!!  An epithymeite na ypaxei desmos metaxy \"{}\" tou krystalou kai \"{}\" tou ligand, exete kata nou oti tha prepei na dwsete apostash 0 ews 0.35nm gia na parete ortha apotelesmata desmwn." .format(atoma_pdb[pdb_atomo_allilepidrashs],ligand_file_pd.iloc[epilogh,1]))        
#         desmos_1= input("Epitheimeite na yparxei desmos yparxei desmos metaxy \"{}\" tou krystalou kai \"{}\" tou ligand. plhktrolohste \"Yes\" an nai , alliws synexiste xwris desmo plhktrolwgontas \"No\"(Yes/No):".format(atoma_pdb[pdb_atomo_allilepidrashs],ligand_file_pd.iloc[epilogh,1]))
#         try:
#             if desmos_1 == "Yes" or desmos_1 == "Y" or desmos_1 == "yes" or desmos_1 == "y":
#                 desmos = True
#                 break
#             elif desmos_1 == "No" or desmos_1 == "N" or desmos_1 == "no" or desmos_1 == "n":
#                 desmos = False
#                 break
#             else:
#                 print("\n***** Den mou edwses (Yes/No) *****\n")
#                 continue
#         except ValueError:
#             continue
#         
# =============================================================================
############################################################################################################################
###################################### APOSTASH TOU DICTIONARY #############################################################
############################################################################################################################
length1=(''.join(x for x in ligand_file_pd.iloc[epilogh,1] if x.isalpha())).capitalize()
length2=(''.join(x for x in atoma_pdb[pdb_atomo_allilepidrashs] if x.isalpha())).capitalize()

len_dict=float("{:}".format(round((dictionary[length1]+dictionary[length2])*0.1,2)))
############################################################################################################################

#################################################################################################
################### ΒΑΖΩ ΤΑ LIGANDS ΣΕ ΜΙΑ ΑΠΟΣΤΑΣΗ ΠΟΥ ΔΙΝΕΙΣ Ο ΧΡΗΣΤΗΣ ########################
#################################################################################################


if check_choice_par == "false":
    desmos = False
else:
    desmos = True


if desmos ==True:
    while True:
        
        try:
            #apostasi_ligand_core_1= input("H apostash metaxy \"{}\" tou krystalou kai \"{}\" tou ligand, einai {:.2f} nm. Apodexeste auth thn apostah h thelete na orisete dikia sas? (yes/no): ".format(atoma_pdb[pdb_atomo_allilepidrashs],ligand_file_pd.iloc[epilogh,1],len_dict))
            apostasi_ligand_core= float(bond_choice_par)
            apostasi_ligand_core=round((apostasi_ligand_core)*10,2)
# =============================================================================
#             if apostasi_ligand_core_1 == "Yes" or apostasi_ligand_core_1 == "Y" or apostasi_ligand_core_1 == "yes" or apostasi_ligand_core_1 == "y":
#                 apostasi_ligand_core=len_dict*10
#                 
#             elif apostasi_ligand_core_1 == "No" or apostasi_ligand_core_1 == "N" or apostasi_ligand_core_1 == "no" or apostasi_ligand_core_1 == "n":
#                 apostasi_ligand_core= input("Dwse mou thn epithymith apostash metaxy \"{}\" tou krystalou kai \"{}\" tou ligand, se nm : ".format(atoma_pdb[pdb_atomo_allilepidrashs],ligand_file_pd.iloc[epilogh,1]))
#                 apostasi_ligand_core=float(apostasi_ligand_core)*10
#                 if apostasi_ligand_core < 0:
#                     print("\n \n *******H apostash den mporei na einai arnitikh*******\n")
#                     continue
#             else:
#                 print("\n***** Den mou edwses (Yes/No) *****\n")
#                 continue
# =============================================================================
            break
        except ValueError:
            print("\n \n *******Dwsmou arithmo *******\n")
            continue   

else:
    while True:
        
        try:
            #apostasi_ligand_core= input("Dwse mou thn epithymith apostash metaxy \"{}\" tou krystalou kai \"{}\" tou ligand, se nm : ".format(atoma_pdb[pdb_atomo_allilepidrashs],ligand_file_pd.iloc[epilogh,1]))
            apostasi_ligand_core=no_bond_choice_par
            apostasi_ligand_core=float(apostasi_ligand_core)*10
            if apostasi_ligand_core < 0:
                print("\n \n *******H apostash den mporei na einai arnitikh*******\n")
                continue
            break
        except ValueError:
            print("\n \n *******Dwsmou arithmo *******\n")
            continue   




           
kentro_ligand=[]
for i in range(len(kentro_ligand_allilepidrasi)):
    apostasi=(np.linalg.norm(kentro_ligand_allilepidrasi[i]))
    kentro_ligand.append((kentro_ligand_allilepidrasi[i] / apostasi) * (apostasi+apostasi_ligand_core))  #TODO ΕΔΩ ΔΙΝΩ ΜΙΑ ΑΠΟΣΤΑΣΗ ΠΟΥ ΘΕΛΩ ΝΑ ΥΠΑΡΧΕΙ ΑΝΑΜΕΣΑ ΣΤΑ ΑΤΟΜΑ









#################################################################################################

#################################################################################################
###############################  ΣΥΝΑΡΤΗΣΗ ROTATION MATRIX   ####################################
#################################################################################################


def rot_matrix(x,y):
    #curve_vec_1=[0.043477,0.036412,0.998391]
    curve_vec_1=x
    curve_vec_2=y
    a,b = (curve_vec_1/ np.linalg.norm(curve_vec_1)).reshape(3), (curve_vec_2/ np.linalg.norm(curve_vec_2)).reshape(3)
    v = np.cross(a,b)
    c = np.dot(a,b)
    s = np.linalg.norm(v)
    I = np.identity(3)
    vXStr = '{} {} {}; {} {} {}; {} {} {}'.format(0, -v[2], v[1], v[2], 0, -v[0], -v[1], v[0], 0)
    k = np.matrix(vXStr)
    rot=(I + k + np.dot(k,k) * ((1 -c)/(s**2)))
    return rot


#################################################################################################


#################################################################################################
############################### ΒΡΙΣΚΩ ΤΟ VECTOR Y ΤΟΥ LIGAND   #################################
#################################################################################################   


ligand_norm=[]
for i in range(len(ligand_coords_teliko)):
    ligand_norm.append(np.linalg.norm(ligand_coords_teliko[i]))

vector_y=ligand_coords_teliko[ligand_norm.index(max(ligand_norm))]-ligand_coords_teliko[epilogh] # VECTOR Y ΓΙΑ ΜΕΤΑ


#################################################################################################
##################### ΒΡΙΣΚΩ ΤΗΝ ΓΩΝΙΑ ΠΟΥ ΘΑ ΠΕΡΙΣΤΡΑΦΕΙ ΤΟ LIGAND   ###########################
#################################################################################################  

gwnies_ligand=[]
for i in range(len(kentro_ligand)):
    gwnies_ligand.append(rot_matrix(kentro_ligand[i],vector_y))  #ΟΠΟΥ ΤΟ ΔΙΑΝΥΣΜΑ Χ είναι η φορά που θα μπει από το κεντρο
    #gwnies_ligand.append(rot_matrix(katheto_dianysma[i],vector_y))  #ΟΠΟΥ ΤΟ ΔΙΑΝΥΣΜΑ Χ είναι η φορά που θα μπει από το κεντρο

ligand_stoixeia=ligand_file_pd.iloc[:,1]


#################################################################################################
##################### ΒΡΙΣΚΩ ΤΗΝ ΓΩΝΙΑ ΠΟΥ ΘΑ ΠΕΡΙΣΤΡΑΦΕΙ ΤΟ LIGAND   ###########################
#################################################################################################  

ligand_stoixeia_1=[]
final_ligands_temp=[]

for i in range(len(gwnies_ligand)):
    for j in range(len(ligand_coords_teliko)):
        final_ligands_temp.append((ligand_coords_teliko[j]*gwnies_ligand[i])+ kentro_ligand[i])
        ligand_stoixeia_1.append(ligand_stoixeia[j])



final_ligands_temp_1=np.stack(final_ligands_temp, axis=0)
final_ligands=pd.DataFrame(final_ligands_temp_1)
#final_ligands.insert(0,'Stoixeio',ligand_stoixeia_1)






##########ZHTAW TO sigma kai to epsilon gia na ftiaxw to top#########################
   

##ΕΛΕΓΧΩ ΑΝ ΜΕΣΑ ΣΤΟ LIGAND ΥΠΑΡΧΕΙ ΤΟ ΣΤΟΙΧΕΙΟ ΗΔΗ, ΑΝ ΝΑΙ,,ΔΕΝ ΞΑΝΑΖΗΤΑΩ sigma και epsilon!!!###  
atoma_pdb_del=[]
for i in range(len(ligand_file_pd)):
    for j in range(len(atoma_pdb)):
        if ligand_file_pd.iloc[i,1][0]==atoma_pdb[j]:
            atoma_pdb_del.append(j)
        
atoma_pdb_del.sort(reverse=True)
atoma_pdb_del = list(dict.fromkeys(atoma_pdb_del))
for i in range(len(atoma_pdb_del)):
    del atoma_pdb[atoma_pdb_del[i]]
#########################################
  
# =============================================================================
# sigma=[]
# epsilon=[]
# 
# while True:
#     try:
#         for i,j in enumerate(atoma_pdb):
#             sigma1=input('Dwse me mou to sigma gia to \'{}\': '.format(j))
#             epsilon1=input('Dwse me mou to epsilon gia to \'{}\': '.format(j))
#             sigma1=float(sigma1)
#             epsilon1=float(epsilon1)
#             sigma.append(sigma1)
#             epsilon.append(epsilon1)
#             print('\nTo \'sigma kai epsilon\' gia to \'{}\' einai egkyroi arithmoi!!! Synexizw.....'.format(j))
#         break
#     except ValueError:
#         print("\n \n *******Kati den mou edwses swsta!!! Dwsmou pali \'sigma kai epsilon\' gia to \'{}\' *******\n".format(j))
#         continue  
# 
# 
# =============================================================================
sigma=[]
epsilon=[]
if ',' in sigma_choice_par:
    sigma=sigma_choice_par.split(',')
    for i in range(len(sigma)):
        sigma[i]=float(sigma[i])
else:
    sigma=[float(sigma_choice_par)]

if ',' in epsilon_choice_par:
    epsilon=epsilon_choice_par.split(',')
    for i in range(len(epsilon)):
        epsilon[i]=float(sigma[i])
else:
    epsilon=[float((epsilon_choice_par).strip())]





































#################################################################################################
#####################               ΤΑ ΓΡΑΦΩ ΣΕ ΑΡΧΕΙΑ                ###########################
################################################################################################# 




if desmos:
    #KOITAW MHPWS KAPOIO ALLO STOIXEIO EINAI IDIO STO LIGAND
    counter_stoix=[]
    for i in range(len(ligand_stoixeia)):
        counter_stoix.append(ligand_stoixeia.iloc[i][0].count(atoma_pdb[pdb_atomo_allilepidrashs]))
    counter_stoix=sum(counter_stoix)
    counter_stoix +=1
    

# =============================================================================
#     if counter_stoix>0:
#         counter_stoix+=1
#     else:
#         counter_stoix=''
#     
# =============================================================================
    ############ FTIAXNW TOUS PINAKES MOU NA EXOUN THN SWSTH MORFH GIA NA FTIAXW ARGOTERA TO PDB ###############
    test=[]
    ligand_resid_bond=[]
    for i in range(len(gwnies_ligand)):
        for j in range(len(ligand_coords_teliko)):
            test.append((ligand_coords_teliko[j]*gwnies_ligand[i])+ kentro_ligand[i])
            ligand_resid_bond.append(i+2)
        test.append([kentro_ligand_allilepidrasi[i]])
        ligand_resid_bond.append(i+2)
    ligand_coords_bond=np.stack(test, axis=0)
    ligand_coords_bond=pd.DataFrame(ligand_coords_bond)
    
    test2=[]
    for i in range(len(gwnies_ligand)):
        for j in range(len(ligand_coords_teliko)):
            test2.append(ligand_stoixeia[j])
        test2.append(atoma_pdb[pdb_atomo_allilepidrashs])
    
    test3=np.stack(test2, axis=0)
    test3=pd.DataFrame(test3)
    
    ligand_coords_bond.insert(0,'res',test3)
    ligand_coords_bond.insert(4,'lig_res',ligand_resid_bond)
    
    
    test4=[]
    for i in range(len(pdb_coords)):
        for j in range(len(kentro_ligand_allilepidrasi)):
            if pdb_coords[i][0] == kentro_ligand_allilepidrasi[j][0] and pdb_coords[i][1] == kentro_ligand_allilepidrasi[j][1] and pdb_coords[i][2] == kentro_ligand_allilepidrasi[j][2]:
                test4.append(i)
    pdb_coords_copy_1=pdb_coords.copy()
    pdb_coords_copy_1=pd.DataFrame(pdb_coords_copy_1)
    
    for i in range(len(test4)):
        pdb_coords_copy_1=pdb_coords_copy_1.drop(test4[i])
    
    test5=list(pdb_coords_copy_1.index.values)
    pdb_coords_bond=[]
    for i in range(len(test5)):
        pdb_coords_bond.append(pdb_arxeio.iloc[test5[i],2:6])
    pdb_coords_bond=pd.DataFrame(pdb_coords_bond) 
    pdb_coords_bond.insert(4,'pdb_res',1)
    
    ##    pdb_coords_bond  ,,,, ligand_coords_bond
    
    
    
    print('\n\nDhmiourgw to top file.......\n\n\n')
    
    final_of_ligands=open('test.pdb', 'w')
    for i in range(len(ligand_file_pd)):
        final_of_ligands.write('HETATM'.ljust(6))
        final_of_ligands.write(str(i+1).rjust(5))
        final_of_ligands.write(' '+str(ligand_file_pd.iloc[i,1]).ljust(4)) 
        final_of_ligands.write(' '+str(ligand_file_pd.iloc[0,7]).ljust(3))
        final_of_ligands.write('  '+str(1).rjust(4))
        final_of_ligands.write('    '+ str('{:.3f}'.format(final_ligands.iloc[i,0])).rjust(8))
        final_of_ligands.write(str('{:.3f}'.format(final_ligands.iloc[i,1])).rjust(8))
        final_of_ligands.write(str('{:.3f}'.format(final_ligands.iloc[i,2])).rjust(8)+"\n")
    final_of_ligands.close()
    os.system("/home/user/miniconda3/bin/./antechamber -i test.pdb -o test.mol2 -fi pdb -fo mol2 -c gas")
    if os.path.isfile('ANTECHAMBER_AC.AC'):
        pass
    else:
        print('@@@@@@@@@@@ To ligands sou periexei stoixeia pou dn ypagontai sta mkra moria @@@@@@@@@@@@@@@@')
        print('@@@@@@@@@@@ Bgainw apo to programma @@@@@@@@@@@@@@@@')
        sys.exit()
    os.system("rm ANTE*")
    os.system("rm ATOMTYPE.INF")
    os.system("acpype -di test.mol2 -c gas")
    os.chdir("test.acpype")
    os.system("mv test_GMX.gro test_GMX.itp test_GMX.top ../")
    os.chdir("../")
    
    
    
        
    with open('test_GMX.itp') as top:
        top_lines=top.readlines()
    
        for i in range(len(top_lines)):                                     #ΔΕΝ ΠΕΙΡΑΖΩΩ ΤΟΥΣ ΤΙΤΛΟΥΣ, ΜΟΝΟ ΟΤΙ ΕΙΝΑΙ ΚΑΤΩ ΑΠΟ ΑΥΤΟΥΣ
            if top_lines[i].startswith('[ atomtypes ]') :
                top_atomtypes=top_lines[i:i+2]
                top_arxi_atomtypes=i+2    
            if top_lines[i].startswith('[ moleculetype ]') :
                top_moleculetype=top_lines[i:i+3]
                top_telos_atomtypes=i-1
                top_arxi_moleculetype=i+2    
            if top_lines[i].startswith('[ atoms ]') :
                top_atoms=top_lines[i:i+2]
                top_telos_moleculetype=i-1
                top_arxi_atoms=i+2  
            if top_lines[i].startswith('[ bonds ]') :
                top_bonds=top_lines[i:i+2]
                top_telos_atoms=i-1
                top_arxi_bonds=i+2
            if top_lines[i].startswith('[ pairs ]') :
                top_pairs=top_lines[i:i+2]
                top_telos_bonds=i-1
                top_arxi_pairs=i+2
            if top_lines[i].startswith('[ angles ]') :
                top_angles=top_lines[i:i+2]
                top_telos_pairs=i-1
                top_arxi_angles=i+2
            if top_lines[i].startswith('[ dihedrals ] ; propers') : 
                top_propers=top_lines[i:i+3]
                top_telos_angles=i-1
                top_arxi_propers=i+3 #Σβήνω 1 επιπλεον γραμμη με text
            if top_lines[i].startswith('[ dihedrals ] ; impropers') :
                top_impropers=top_lines[i:i+3]
                top_telos_propers=i-1
                top_arxi_impropers=i+3  #Σβήνω 1 επιπλεον γραμμη με text
                top_telos_impropers=len(top_lines)
    
    toptop_atomtypes = "".join(top_lines[top_arxi_atomtypes:top_telos_atomtypes])
    top_atomtypes_pd = pd.DataFrame([x.split() for x in toptop_atomtypes.split('\n')])
    top_atomtypes_pd=top_atomtypes_pd.drop(top_atomtypes_pd.index[len(top_atomtypes_pd)-1])
    
    toptop_moleculetype = "".join(top_lines[top_arxi_moleculetype:top_telos_moleculetype])
    top_moleculetype_pd = pd.DataFrame([x.split() for x in toptop_moleculetype.split('\n')])
    top_moleculetype_pd=top_moleculetype_pd.drop(top_moleculetype_pd.index[len(top_moleculetype_pd)-1])

    toptop_atoms = "".join(top_lines[top_arxi_atoms:top_telos_atoms])
    top_atoms_pd = pd.DataFrame([x.split() for x in toptop_atoms.split('\n')])
    top_atoms_pd=top_atoms_pd.drop(top_atoms_pd.index[len(top_atoms_pd)-1])
    
    toptop_bonds = "".join(top_lines[top_arxi_bonds:top_telos_bonds])
    top_bonds_pd = pd.DataFrame([x.split() for x in toptop_bonds.split('\n')])
    top_bonds_pd=top_bonds_pd.drop(top_bonds_pd.index[len(top_bonds_pd)-1])
    
    toptop_pairs = "".join(top_lines[top_arxi_pairs:top_telos_pairs])
    top_pairs_pd = pd.DataFrame([x.split() for x in toptop_pairs.split('\n')])
    top_pairs_pd=top_pairs_pd.drop(top_pairs_pd.index[len(top_pairs_pd)-1])

    
    toptop_angles = "".join(top_lines[top_arxi_angles:top_telos_angles])
    top_angles_pd = pd.DataFrame([x.split() for x in toptop_angles.split('\n')])
    top_angles_pd=top_angles_pd.drop(top_angles_pd.index[len(top_angles_pd)-1])

    
    toptop_propers = "".join(top_lines[top_arxi_propers:top_telos_propers])
    top_propers_pd = pd.DataFrame([x.split() for x in toptop_propers.split('\n')])
    top_propers_pd=top_propers_pd.drop(top_propers_pd.index[len(top_propers_pd)-1])

    
    toptop_impropers = "".join(top_lines[top_arxi_impropers:top_telos_impropers])
    top_impropers_pd = pd.DataFrame([x.split() for x in toptop_impropers.split('\n')])
    top_impropers_pd=top_impropers_pd.drop(top_impropers_pd.index[len(top_impropers_pd)-1])
    
    
    

    toptop_moleculetype = "".join(top_lines[top_arxi_moleculetype:top_telos_moleculetype])
    top_moleculetype_pd = pd.DataFrame([x.split() for x in toptop_moleculetype.split('\n')])
    top_moleculetype_pd=top_moleculetype_pd.drop(top_moleculetype_pd.index[len(top_moleculetype_pd)-1])

    toptop_atoms = "".join(top_lines[top_arxi_atoms:top_telos_atoms])
    top_atoms_pd = pd.DataFrame([x.split() for x in toptop_atoms.split('\n')])
    top_atoms_pd=top_atoms_pd.drop(top_atoms_pd.index[len(top_atoms_pd)-1])
    data_atoms=[str(len(top_atoms_pd)+1),str(atoma_pdb[pdb_atomo_allilepidrashs]),top_atoms_pd.iloc[0,2],top_atoms_pd.iloc[0,3],str(atoma_pdb[pdb_atomo_allilepidrashs])+str(counter_stoix),str(len(top_atoms_pd)+1),'0.000000','{:.5f}'.format(atomic_masses[atomic_numbers[("".join(x for x in atoma_pdb[pdb_atomo_allilepidrashs] if x.isalpha())).capitalize()]]),top_atoms_pd.iloc[0,8],top_atoms_pd.iloc[0,9],'0.000']
    top_atoms_pd.loc[len(top_atoms_pd)]=data_atoms

 


    toptop_bonds = "".join(top_lines[top_arxi_bonds:top_telos_bonds])
    top_bonds_pd = pd.DataFrame([x.split() for x in toptop_bonds.split('\n')])
    top_bonds_pd=top_bonds_pd.drop(top_bonds_pd.index[len(top_bonds_pd)-1])
    for i in range(len(top_bonds_pd)):
        if top_bonds_pd.iloc[i,1]==epilogh_test:
            timh=i
            break;
        else:
            timh = int(epilogh_test)
            
    data_bonds=[str(epilogh_test),str(len(top_atoms_pd)),top_bonds_pd.iloc[0,2],'{:.4e}'.format(apostasi_ligand_core*0.1),top_bonds_pd.iloc[timh,4],top_bonds_pd.iloc[0,5],str(lig_choice_par),top_bonds_pd.iloc[timh,7],str(atoma_pdb[pdb_atomo_allilepidrashs])+str(counter_stoix)]
    top_bonds_pd.loc[len(top_bonds_pd)]=data_bonds
    ###To bazw sta angles gia na krathsw thn timh
    #top_bonds_pd.iloc[:,0]=top_bonds_pd.iloc[:,0].astype(int)
    #top_bonds_pd=top_bonds_pd.sort_values(by=[0])
 

    toptop_pairs = "".join(top_lines[top_arxi_pairs:top_telos_pairs])
    top_pairs_pd = pd.DataFrame([x.split() for x in toptop_pairs.split('\n')])
    top_pairs_pd=top_pairs_pd.drop(top_pairs_pd.index[len(top_pairs_pd)-1])
    data_pairs=[str(epilogh_test),str(len(top_atoms_pd)),top_pairs_pd.iloc[0,2],top_pairs_pd.iloc[0,3],str(lig_choice_par),top_pairs_pd.iloc[0,5],str(atoma_pdb[pdb_atomo_allilepidrashs])+str(counter_stoix)]
    top_pairs_pd.loc[len(top_pairs_pd)]=data_pairs
    top_pairs_pd.iloc[:,0]=top_pairs_pd.iloc[:,0].astype(int)
    top_pairs_pd=top_pairs_pd.sort_values(by=[0])

    toptop_angles = "".join(top_lines[top_arxi_angles:top_telos_angles])
    top_angles_pd = pd.DataFrame([x.split() for x in toptop_angles.split('\n')])
    top_angles_pd=top_angles_pd.drop(top_angles_pd.index[len(top_angles_pd)-1])
    data_angles=[str(top_bonds_pd.iloc[timh,0]),str(top_bonds_pd.iloc[timh,1]),str(len(top_atoms_pd)),top_angles_pd.iloc[0,3],'{:.4e}'.format(0),'{:.4e}'.format(0),top_angles_pd.iloc[0,6],str(top_bonds_pd.iloc[timh,6]),top_angles_pd.iloc[0,8],str(top_bonds_pd.iloc[timh,8]),top_angles_pd.iloc[0,10],str(atoma_pdb[pdb_atomo_allilepidrashs])+str(counter_stoix)]
    top_angles_pd.loc[len(top_angles_pd)]=data_angles
    top_angles_pd.iloc[:,0]=top_angles_pd.iloc[:,0].astype(int)
    top_angles_pd=top_angles_pd.sort_values(by=[0])
    ####
    top_bonds_pd.iloc[:,0]=top_bonds_pd.iloc[:,0].astype(int)
    top_bonds_pd=top_bonds_pd.sort_values(by=[0])
    ###
    
    
    toptop_propers = "".join(top_lines[top_arxi_propers:top_telos_propers])
    top_propers_pd = pd.DataFrame([x.split() for x in toptop_propers.split('\n')])
    top_propers_pd=top_propers_pd.drop(top_propers_pd.index[len(top_propers_pd)-1])

    
    toptop_impropers = "".join(top_lines[top_arxi_impropers:top_telos_impropers])
    top_impropers_pd = pd.DataFrame([x.split() for x in toptop_impropers.split('\n')])
    top_impropers_pd=top_impropers_pd.drop(top_impropers_pd.index[len(top_impropers_pd)-1])



    top_ligands_atoms=[]
    m=len(pdb_coords_bond)
    l=1                                 #To bazw 2 giati to 1o resid einai "1" O krystalos einai sympaghs
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_atoms_pd)):
            top_ligands_atoms.append([int(top_atoms_pd.iloc[j,0])+m , top_atoms_pd.iloc[j,1] , (int(top_atoms_pd.iloc[j,2])*i)+l , top_atoms_pd.iloc[j,3] , top_atoms_pd.iloc[j,4] , int(top_atoms_pd.iloc[j,5])+m , top_atoms_pd.iloc[j,6] , top_atoms_pd.iloc[j,7] ,top_atoms_pd.iloc[j,8] , top_atoms_pd.iloc[j,9] , top_atoms_pd.iloc[j,10] ])
        m+=len(top_atoms_pd)    
    
    
    top_ligands_bonds=[]
    m=len(pdb_coords_bond)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_bonds_pd)):
            top_ligands_bonds.append([int(top_bonds_pd.iloc[j,0])+m , int(top_bonds_pd.iloc[j,1])+m , top_bonds_pd.iloc[j,2] , top_bonds_pd.iloc[j,3] , top_bonds_pd.iloc[j,4] ,  top_bonds_pd.iloc[j,5] ,  top_bonds_pd.iloc[j,6] ,top_bonds_pd.iloc[j,7] ,top_bonds_pd.iloc[j,8]])
        m+=len(top_atoms_pd) 
    

    top_ligands_pairs=[]
    m=len(pdb_coords_bond)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_pairs_pd)):
            top_ligands_pairs.append([int(top_pairs_pd.iloc[j,0])+m , int(top_pairs_pd.iloc[j,1])+m , top_pairs_pd.iloc[j,2], top_pairs_pd.iloc[j,3] , top_pairs_pd.iloc[j,4] ,  top_pairs_pd.iloc[j,5] ,  top_pairs_pd.iloc[j,6]])
        m+=len(top_atoms_pd) 
    
    top_ligands_angles=[]
    m=len(pdb_coords_bond)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_angles_pd)):
            top_ligands_angles.append([int(top_angles_pd.iloc[j,0])+m , int(top_angles_pd.iloc[j,1])+m , int(top_angles_pd.iloc[j,2])+m , top_angles_pd.iloc[j,3] , top_angles_pd.iloc[j,4] , top_angles_pd.iloc[j,5] ,  top_angles_pd.iloc[j,6] ,  top_angles_pd.iloc[j,7] , top_angles_pd.iloc[j,8] , top_angles_pd.iloc[j,9] , top_angles_pd.iloc[j,10] , top_angles_pd.iloc[j,11]])
        m+=len(top_atoms_pd) 

    top_ligands_propers=[]
    m=len(pdb_coords_bond)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_propers_pd)):
            top_ligands_propers.append([int(top_propers_pd.iloc[j,0])+m , int(top_propers_pd.iloc[j,1])+m , int(top_propers_pd.iloc[j,2])+m , int(top_propers_pd.iloc[j,3])+m , top_propers_pd.iloc[j,4] , top_propers_pd.iloc[j,5] , top_propers_pd.iloc[j,6] , top_propers_pd.iloc[j,7] , top_propers_pd.iloc[j,8] , top_propers_pd.iloc[j,9] , top_propers_pd.iloc[j,10] , top_propers_pd.iloc[j,11] , top_propers_pd.iloc[j,12]] )
        m+=len(top_atoms_pd) 
        
    top_ligands_impropers=[]
    m=len(pdb_coords_bond)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_impropers_pd)):
            top_ligands_impropers.append([int(top_impropers_pd.iloc[j,0])+m , int(top_impropers_pd.iloc[j,1])+m , int(top_impropers_pd.iloc[j,2])+m , int(top_impropers_pd.iloc[j,3])+m , top_impropers_pd.iloc[j,4] , top_impropers_pd.iloc[j,5] , top_impropers_pd.iloc[j,6] , top_impropers_pd.iloc[j,7] , top_impropers_pd.iloc[j,8] , top_impropers_pd.iloc[j,9] , top_impropers_pd.iloc[j,10] , top_impropers_pd.iloc[j,11] , top_impropers_pd.iloc[j,12]] )
        m+=len(top_atoms_pd) 
    

    top_ligands_atoms=pd.DataFrame(top_ligands_atoms)
    top_ligands_bonds=pd.DataFrame(top_ligands_bonds)
    top_ligands_pairs=pd.DataFrame(top_ligands_pairs)
    top_ligands_angles=pd.DataFrame(top_ligands_angles)
    top_ligands_propers=pd.DataFrame(top_ligands_propers)
    top_ligands_impropers=pd.DataFrame(top_ligands_impropers)
    
    
    ####################################################################################################
    ##################ΣΥΜΠΛΗΡΩΝΩ ΣΤΟ TOPOLOGY ΤΟΥ LIGAND,ΤΑ ΣΤΟΙΧΕΙΑ ΤΟΝ ΚΡΥΣΤΑΛΟΥ #####################
    ####################################################################################################
    
    top_atomtypes_temp=[]
    for i in range(len(atoma_pdb)):
        top_atomtypes_temp.append([atoma_pdb[i],atoma_pdb[i],top_atomtypes_pd.iloc[i,2],top_atomtypes_pd.iloc[i,3],top_atomtypes_pd.iloc[i,4],'{:.5e}'.format(sigma[i]),'{:.5e}'.format(epsilon[i]),top_atomtypes_pd.iloc[i,7],str(round((sigma[i]/(2**0.83333)*10),2)),str(round((epsilon[i]/4.184),4))])
    top_atomtypes_temp=pd.DataFrame(top_atomtypes_temp)
    top_atomtypes_pd = pd.concat([top_atomtypes_temp, top_atomtypes_pd]).reset_index(drop = True)
    #round((sigma/(2**0.83333)*10),4)
    #round((epsilon/4.184)),4)
    top_atoms_temp=[]
    for i in range(len(pdb_coords_bond)):
        top_atoms_temp.append([str(i+1),pdb_coords_bond.iloc[i,0].upper(),'1',pdb_coords_bond.iloc[i,0],pdb_coords_bond.iloc[i,0],str(i+1),'0.000000','{:.5f}'.format(atomic_masses[atomic_numbers[("".join(x for x in pdb_coords_bond.iloc[i,0] if x.isalpha())).capitalize()]]),top_ligands_atoms.iloc[0,8],top_ligands_atoms.iloc[0,9],'0.000'])
    top_atoms_temp=pd.DataFrame(top_atoms_temp)
    top_ligands_atoms=pd.concat([top_atoms_temp, top_ligands_atoms]).reset_index(drop = True)
    top_ligands_atoms=top_ligands_atoms.astype(str)




    ####################################################################################################
    ##################              ΓΡΑΦΩ ΤΟ TOPOLOGY FILE            ##################################
    ####################################################################################################    
    
    #DIAVAZW TA ARXIKA KAI TA TELEYTAIA APO TOP
    with open('test_GMX.top','r') as itp:
        itp_lines=itp.readlines()
        topol_arxika=("".join(itp_lines[0:6]))
        topol_telika=("".join(itp_lines[8:]))
    
    
    
    
    
    zzz=open(pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_bonded.top', 'w')        #DHMIOURGW TO TOPOLOGY ARXEIO
    
    zzz.write(topol_arxika)
    
    for item in top_atomtypes:                #GRAFW TO ATOMTYPES
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_atomtypes_pd)):
        zzz.write(' '+(top_atomtypes_pd.iloc[i,0].upper()).ljust(9))
        zzz.write(''+(top_atomtypes_pd.iloc[i,1].upper()).ljust(4))
        zzz.write(''+(top_atomtypes_pd.iloc[i,2].rjust(17)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,3].rjust(9)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,4].rjust(4)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,5].rjust(16)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,6].rjust(14)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,7].rjust(2)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,8].rjust(5)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,9].rjust(8))+'\n')
    zzz.write("\n")
    
    for item in top_moleculetype:               #GRAFW TO MOLECULETYPE
        zzz.write("%s\n" % item.rstrip())
    zzz.write("\n")   
    
    for item in top_atoms:                      #GRAFW TA ATOMS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_atoms)):
        zzz.write(''+(top_ligands_atoms.iloc[i,0]).rjust(6))
        zzz.write(''+((top_ligands_atoms.iloc[i,1]).upper()).rjust(5))
        zzz.write(''+(top_ligands_atoms.iloc[i,2]).rjust(6))
        zzz.write(''+(top_ligands_atoms.iloc[i,3].rjust(6)))
        zzz.write(''+(top_ligands_atoms.iloc[i,4].rjust(6)))
        zzz.write(''+((top_ligands_atoms.iloc[i,5]).rjust(5)))
        zzz.write(''+(top_ligands_atoms.iloc[i,6].rjust(13)))
        zzz.write(''+(top_ligands_atoms.iloc[i,7].rjust(13)))
        zzz.write(''+(top_ligands_atoms.iloc[i,8].rjust(2)))
        zzz.write(''+(top_ligands_atoms.iloc[i,9].rjust(5)))
        zzz.write(''+(top_ligands_atoms.iloc[i,10].rjust(8))+'\n')
    zzz.write("\n")

    for item in top_bonds:                      #GRAFW TA BONDS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_bonds)):
        zzz.write(''+(top_ligands_bonds.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_bonds.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_bonds.iloc[i,2]).rjust(4))
        zzz.write(''+(top_ligands_bonds.iloc[i,3]).rjust(14))
        zzz.write(''+(top_ligands_bonds.iloc[i,4]).rjust(14))
        zzz.write(''+(top_ligands_bonds.iloc[i,5]).rjust(2))
        zzz.write(''+(top_ligands_bonds.iloc[i,6]).rjust(7))
        zzz.write(''+(top_ligands_bonds.iloc[i,7]).rjust(2))
        zzz.write(''+(top_ligands_bonds.iloc[i,8]).rjust(3)+'\n')
    zzz.write("\n")
    
    for item in top_pairs:                      #GRAFW TA PAIRS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_pairs)):
        zzz.write(''+(top_ligands_pairs.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_pairs.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_pairs.iloc[i,2].rjust(7)))
        zzz.write(''+(top_ligands_pairs.iloc[i,3].rjust(2)))
        zzz.write(''+(top_ligands_pairs.iloc[i,4]).rjust(7))
        zzz.write(''+(top_ligands_pairs.iloc[i,5]).rjust(2))
        zzz.write(''+(top_ligands_pairs.iloc[i,6]).rjust(3)+'\n')
    zzz.write("\n")
    
    for item in top_angles:                      #GRAFW TA ANGLES
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_angles)):
        zzz.write(''+(top_ligands_angles.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_angles.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,2].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,3]).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,4]).rjust(14))
        zzz.write(''+(top_ligands_angles.iloc[i,5]).rjust(14))
        zzz.write(''+(top_ligands_angles.iloc[i,6]).rjust(2))
        zzz.write(''+(top_ligands_angles.iloc[i,7]).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,8]).rjust(2))
        zzz.write(''+(top_ligands_angles.iloc[i,9]).rjust(3))
        zzz.write(''+(top_ligands_angles.iloc[i,10]).rjust(6))
        zzz.write(''+(top_ligands_angles.iloc[i,11]).rjust(3)+'\n')
    zzz.write("\n")
    
    for item in top_propers:                      #GRAFW TA DIHEDRALS -PROPERS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_propers)):
        zzz.write(''+(top_ligands_propers.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_propers.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,2].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,3].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,4]).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,5]).rjust(9))
        zzz.write(''+(top_ligands_propers.iloc[i,6]).rjust(10))
        zzz.write(''+(top_ligands_propers.iloc[i,7]).rjust(4))
        zzz.write(''+(top_ligands_propers.iloc[i,8]).rjust(2))
        zzz.write(''+(top_ligands_propers.iloc[i,9]).rjust(8))
        zzz.write(''+(top_ligands_propers.iloc[i,10]).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,11]).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,12]).rjust(6)+'\n')
    zzz.write("\n")
    
    for item in top_impropers:                      #GRAFW TA DIHEDRALS -IMPROPERS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_impropers)):
        zzz.write(''+(top_ligands_impropers.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_impropers.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,2].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,3].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,4]).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,5]).rjust(9))
        zzz.write(''+(top_ligands_impropers.iloc[i,6]).rjust(10))
        zzz.write(''+(top_ligands_impropers.iloc[i,7]).rjust(4))
        zzz.write(''+(top_ligands_impropers.iloc[i,8]).rjust(2))
        zzz.write(''+(top_ligands_impropers.iloc[i,9]).rjust(8))
        zzz.write(''+(top_ligands_impropers.iloc[i,10]).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,11]).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,12]).rjust(6)+'\n')

    zzz.write(topol_telika)
    zzz.close()
    
    print('Teleiwsa to top file...')    




 #DHMIOURGW TO PDB ARXEIO#
    print('Dhmiourgw to pdb arxeio...')
    
    temp_teliko = pd.DataFrame( np.concatenate( (pdb_coords_bond, ligand_coords_bond), axis=0 ) )
    
    ##### ΦΤΙΑΧΝΩ ΤΟ CONNECT ############

    
    connect_data=[int(len(ligand_coords_arxiko)+1),int(epilogh_test)]
    connect_1.append(connect_data)
    for i in range(len(connect_1)):
        if connect_1[i][0]==int(epilogh_test):
            connect_1[i][1].append(len(connect_1))
            connect_1[i][1].sort()
    connect_2=[]
    for i in range(len(connect_1)):
        connect_2.append(np.hstack(connect_1[i]))        

 
    connect_2=pd.DataFrame(connect_2)
    
    connect_2=connect_2+len(pdb_coords_bond)
    
    l=len(connect_2)
    for i in range(0,len(gwnies_ligand)):
        connect.append(connect_2+(l*i))
    
    

    
    cell=[]
    for i in range(len(connect)):
        for j in range(len(connect[0])):
            cell.append((connect[i].loc[j]))
    
    
    
    cell2=np.array(cell).astype(int)
    cell1=np.where(cell2<0,'',cell2)
    temp_teliko.iloc[:,1:4]=temp_teliko.iloc[:,1:4].astype(float)
    
   
    
  
    zzz1=open(pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_bonded.pdb', 'w')

    for i in range(len(temp_teliko)):
        if len(top_ligands_atoms.iloc[i,4])<=3:
            zzz1.write('HETATM{:>5}  {:<3} {:<3}{:>6}{:12.3f}{:8.3f}{:8.3f}{:>6.2f}{:>6.2f}{:>12}\n'.format(str(top_ligands_atoms.iloc[i,0]),top_ligands_atoms.iloc[i,4],top_ligands_atoms.iloc[i,3],top_ligands_atoms.iloc[i,2],temp_teliko.iloc[i,1],temp_teliko.iloc[i,2],temp_teliko.iloc[i,3],0,0,(''.join(filter(str.isalpha, top_ligands_atoms.iloc[i,4]))).upper()))
        else:
            zzz1.write('HETATM{:>5} {:<4} {:<3}{:>6}{:12.3f}{:8.3f}{:8.3f}{:>6.2f}{:>6.2f}{:>13}\n'.format(str(top_ligands_atoms.iloc[i,0]),top_ligands_atoms.iloc[i,4],top_ligands_atoms.iloc[i,3],top_ligands_atoms.iloc[i,2],temp_teliko.iloc[i,1],temp_teliko.iloc[i,2],temp_teliko.iloc[i,3],0,0,(''.join(filter(str.isalpha, top_ligands_atoms.iloc[i,4]))).upper()))

    zzz1.write("CONECT{:}".format(''))
    for i in range(len(cell1)):   
        for j in range(len(cell1[0])):
            if cell1[i][j] =='':
                pass
            else:
                zzz1.write("{:>5}".format(str(cell1[i][j])))
        zzz1.write("\nCONECT{:}".format(''))
    zzz1.close()
    deleter="'"+pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_bonded.pdb'+"'"
    os.system('sed -i "$ d" {0}'.format(deleter))
    print('Teleiwsa to pdb arxeio...')
    
    
    print('Dhmiourgw to gro arxeio...')
    zzz2=open(pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_bonded.gro','w')
    zzz2.write(str('Created by John Nasto')+'\n')
    zzz2.write('{:>5}\n'.format(len(temp_teliko)))
    for i in range(len(temp_teliko)):
        zzz2.write('{:>5}{:>5}{:>5}{:>5}{:8.3f}{:8.3f}{:8.3f}\n'.format(top_ligands_atoms.iloc[i,2],top_ligands_atoms.iloc[i,3],top_ligands_atoms.iloc[i,4],top_ligands_atoms.iloc[i,0],temp_teliko.iloc[i,1]*0.1,temp_teliko.iloc[i,2]*0.1,temp_teliko.iloc[i,3]*0.1))
    zzz2.write('    0.00000     0.00000     0.00000'+'\n')
    zzz2.close()
    print('Teleiwsa to gro arxeio...')
    os.system("rm -rf test*")
    os.system("mv "+ligand_info_name+" "+pdb_info_name+ " "+ pdb_info_name.split('.')[0]+'_and_'+ligand_info_name.split('.')[0]+"/")
    helper = open ('help.txt','w')
    helper.write(str(pdb_info_name.split('.')[0]+'_and_'+ligand_info_name.split('.')[0]))
    helper.close()
    os.system("mv *+*.pdb *+*.gro *+*.top "+pdb_info_name.split('.')[0]+'_and_'+ligand_info_name.split('.')[0]+"/")
    teliko_teliko=open('ok.html','w')
    teliko_teliko.write('ok')
    teliko_teliko.close()
    print('Telos programmatos')



















































































else:
    

    #################################################################################################
    #####################               ΔΟΥΛΕΥΩ ΜΕ ΤΟ ACPYPE                #########################
    #################################################################################################         
    print('\n\nDhmiourgw to top file.......\n\n\n')
    
    final_of_ligands=open('test.pdb', 'w')
    for i in range(len(ligand_file_pd)):
        final_of_ligands.write('HETATM'.ljust(6))
        final_of_ligands.write(str(i+1).rjust(5))
        final_of_ligands.write(' '+str(ligand_file_pd.iloc[i,1]).ljust(4)) 
        final_of_ligands.write(' '+str(ligand_file_pd.iloc[0,7]).ljust(3))
        final_of_ligands.write('  '+str(1).rjust(4))
        final_of_ligands.write('    '+ str('{:.3f}'.format(final_ligands.iloc[i,0])).rjust(8))
        final_of_ligands.write(str('{:.3f}'.format(final_ligands.iloc[i,1])).rjust(8))
        final_of_ligands.write(str('{:.3f}'.format(final_ligands.iloc[i,2])).rjust(8)+"\n")
    final_of_ligands.close()
    os.system("chmod 777 test.pdb")
    os.system("/home/user/miniconda3/bin/./antechamber -i test.pdb -o test.mol2 -fi pdb -fo mol2 -c gas")
    os.system("chmod 777 test.mol2")
    if os.path.isfile('ANTECHAMBER_AC.AC'):
        pass
    else:
        print('@@@@@@@@@@@ To ligands sou periexei stoixeia pou dn ypagontai sta mkra moria @@@@@@@@@@@@@@@@')
        print('@@@@@@@@@@@ Bgainw apo to programma @@@@@@@@@@@@@@@@')
        sys.exit()
    os.system("rm ANTE*")
    os.system("rm ATOMTYPE.INF")
    os.system("acpype -di test.mol2 -c gas")
    os.chdir("test.acpype")
    os.system("mv test_GMX.gro test_GMX.itp test_GMX.top ../")
    os.chdir("../")


    
    with open('test_GMX.itp') as top:
        top_lines=top.readlines()
    
        for i in range(len(top_lines)):                                     #ΔΕΝ ΠΕΙΡΑΖΩΩ ΤΟΥΣ ΤΙΤΛΟΥΣ, ΜΟΝΟ ΟΤΙ ΕΙΝΑΙ ΚΑΤΩ ΑΠΟ ΑΥΤΟΥΣ
            if top_lines[i].startswith('[ atomtypes ]') :
                top_atomtypes=top_lines[i:i+2]
                top_arxi_atomtypes=i+2    
            if top_lines[i].startswith('[ moleculetype ]') :
                top_moleculetype=top_lines[i:i+3]
                top_telos_atomtypes=i-1
                top_arxi_moleculetype=i+2    
            if top_lines[i].startswith('[ atoms ]') :
                top_atoms=top_lines[i:i+2]
                top_telos_moleculetype=i-1
                top_arxi_atoms=i+2  
            if top_lines[i].startswith('[ bonds ]') :
                top_bonds=top_lines[i:i+2]
                top_telos_atoms=i-1
                top_arxi_bonds=i+2
            if top_lines[i].startswith('[ pairs ]') :
                top_pairs=top_lines[i:i+2]
                top_telos_bonds=i-1
                top_arxi_pairs=i+2
            if top_lines[i].startswith('[ angles ]') :
                top_angles=top_lines[i:i+2]
                top_telos_pairs=i-1
                top_arxi_angles=i+2
            if top_lines[i].startswith('[ dihedrals ] ; propers') : 
                top_propers=top_lines[i:i+3]
                top_telos_angles=i-1
                top_arxi_propers=i+3 #Σβήνω 1 επιπλεον γραμμη με text
            if top_lines[i].startswith('[ dihedrals ] ; impropers') :
                top_impropers=top_lines[i:i+3]
                top_telos_propers=i-1
                top_arxi_impropers=i+3  #Σβήνω 1 επιπλεον γραμμη με text
                top_telos_impropers=len(top_lines)
    
    toptop_atomtypes = "".join(top_lines[top_arxi_atomtypes:top_telos_atomtypes])
    top_atomtypes_pd = pd.DataFrame([x.split() for x in toptop_atomtypes.split('\n')])
    top_atomtypes_pd=top_atomtypes_pd.drop(top_atomtypes_pd.index[len(top_atomtypes_pd)-1])
    
    toptop_moleculetype = "".join(top_lines[top_arxi_moleculetype:top_telos_moleculetype])
    top_moleculetype_pd = pd.DataFrame([x.split() for x in toptop_moleculetype.split('\n')])
    top_moleculetype_pd=top_moleculetype_pd.drop(top_moleculetype_pd.index[len(top_moleculetype_pd)-1])

    toptop_atoms = "".join(top_lines[top_arxi_atoms:top_telos_atoms])
    top_atoms_pd = pd.DataFrame([x.split() for x in toptop_atoms.split('\n')])
    top_atoms_pd=top_atoms_pd.drop(top_atoms_pd.index[len(top_atoms_pd)-1])
    
    toptop_bonds = "".join(top_lines[top_arxi_bonds:top_telos_bonds])
    top_bonds_pd = pd.DataFrame([x.split() for x in toptop_bonds.split('\n')])
    top_bonds_pd=top_bonds_pd.drop(top_bonds_pd.index[len(top_bonds_pd)-1])
    
    toptop_pairs = "".join(top_lines[top_arxi_pairs:top_telos_pairs])
    top_pairs_pd = pd.DataFrame([x.split() for x in toptop_pairs.split('\n')])
    top_pairs_pd=top_pairs_pd.drop(top_pairs_pd.index[len(top_pairs_pd)-1])

    
    toptop_angles = "".join(top_lines[top_arxi_angles:top_telos_angles])
    top_angles_pd = pd.DataFrame([x.split() for x in toptop_angles.split('\n')])
    top_angles_pd=top_angles_pd.drop(top_angles_pd.index[len(top_angles_pd)-1])

    
    toptop_propers = "".join(top_lines[top_arxi_propers:top_telos_propers])
    top_propers_pd = pd.DataFrame([x.split() for x in toptop_propers.split('\n')])
    top_propers_pd=top_propers_pd.drop(top_propers_pd.index[len(top_propers_pd)-1])

    
    toptop_impropers = "".join(top_lines[top_arxi_impropers:top_telos_impropers])
    top_impropers_pd = pd.DataFrame([x.split() for x in toptop_impropers.split('\n')])
    top_impropers_pd=top_impropers_pd.drop(top_impropers_pd.index[len(top_impropers_pd)-1])
    
    
    top_ligands_atoms=[]
    m=len(pdb_arxeio)
    l=1                                 #To bazw 2 giati to 1o resid einai "1" O krystalos einai sympaghs
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_atoms_pd)):
            top_ligands_atoms.append([int(top_atoms_pd.iloc[j,0])+m , top_atoms_pd.iloc[j,1] , (int(top_atoms_pd.iloc[j,2])*i)+l , top_atoms_pd.iloc[j,3] , top_atoms_pd.iloc[j,4] , int(top_atoms_pd.iloc[j,5])+m , top_atoms_pd.iloc[j,6] , top_atoms_pd.iloc[j,7] ,top_atoms_pd.iloc[j,8] , top_atoms_pd.iloc[j,9] , top_atoms_pd.iloc[j,10] ])
        m+=len(top_atoms_pd)    
    
    top_ligands_bonds=[]
    m=len(pdb_arxeio)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_bonds_pd)):
            top_ligands_bonds.append([int(top_bonds_pd.iloc[j,0])+m , int(top_bonds_pd.iloc[j,1])+m , top_bonds_pd.iloc[j,2] , top_bonds_pd.iloc[j,3] , top_bonds_pd.iloc[j,4] ,  top_bonds_pd.iloc[j,5] ,  top_bonds_pd.iloc[j,6] ,top_bonds_pd.iloc[j,7] ,top_bonds_pd.iloc[j,8]])
        m+=len(top_atoms_pd) 
    
    top_ligands_pairs=[]
    m=len(pdb_arxeio)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_pairs_pd)):
            top_ligands_pairs.append([int(top_pairs_pd.iloc[j,0])+m , int(top_pairs_pd.iloc[j,1])+m , top_pairs_pd.iloc[j,2], top_pairs_pd.iloc[j,3] , top_pairs_pd.iloc[j,4] ,  top_pairs_pd.iloc[j,5] ,  top_pairs_pd.iloc[j,6]])
        m+=len(top_atoms_pd) 
    
    top_ligands_angles=[]
    m=len(pdb_arxeio)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_angles_pd)):
            top_ligands_angles.append([int(top_angles_pd.iloc[j,0])+m , int(top_angles_pd.iloc[j,1])+m , int(top_angles_pd.iloc[j,2])+m , top_angles_pd.iloc[j,3] , top_angles_pd.iloc[j,4] , top_angles_pd.iloc[j,5] ,  top_angles_pd.iloc[j,6] ,  top_angles_pd.iloc[j,7] , top_angles_pd.iloc[j,8] , top_angles_pd.iloc[j,9] , top_angles_pd.iloc[j,10] , top_angles_pd.iloc[j,11]])
        m+=len(top_atoms_pd) 
    
    top_ligands_propers=[]
    m=len(pdb_arxeio)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_propers_pd)):
            top_ligands_propers.append([int(top_propers_pd.iloc[j,0])+m , int(top_propers_pd.iloc[j,1])+m , int(top_propers_pd.iloc[j,2])+m , int(top_propers_pd.iloc[j,3])+m , top_propers_pd.iloc[j,4] , top_propers_pd.iloc[j,5] , top_propers_pd.iloc[j,6] , top_propers_pd.iloc[j,7] , top_propers_pd.iloc[j,8] , top_propers_pd.iloc[j,9] , top_propers_pd.iloc[j,10] , top_propers_pd.iloc[j,11] , top_propers_pd.iloc[j,12]] )
        m+=len(top_atoms_pd) 
        
    top_ligands_impropers=[]
    m=len(pdb_arxeio)
    for i in range(1,len(gwnies_ligand)+1):
        for j in range(len(top_impropers_pd)):
            top_ligands_impropers.append([int(top_impropers_pd.iloc[j,0])+m , int(top_impropers_pd.iloc[j,1])+m , int(top_impropers_pd.iloc[j,2])+m , int(top_impropers_pd.iloc[j,3])+m , top_impropers_pd.iloc[j,4] , top_impropers_pd.iloc[j,5] , top_impropers_pd.iloc[j,6] , top_impropers_pd.iloc[j,7] , top_impropers_pd.iloc[j,8] , top_impropers_pd.iloc[j,9] , top_impropers_pd.iloc[j,10] , top_impropers_pd.iloc[j,11] , top_impropers_pd.iloc[j,12]] )
        m+=len(top_atoms_pd) 
    
    
    top_ligands_atoms=pd.DataFrame(top_ligands_atoms)
    top_ligands_bonds=pd.DataFrame(top_ligands_bonds)
    top_ligands_pairs=pd.DataFrame(top_ligands_pairs)
    top_ligands_angles=pd.DataFrame(top_ligands_angles)
    top_ligands_propers=pd.DataFrame(top_ligands_propers)
    top_ligands_impropers=pd.DataFrame(top_ligands_impropers)


        
    ####################################################################################################
    ##################ΣΥΜΠΛΗΡΩΝΩ ΣΤΟ TOPOLOGY ΤΟΥ LIGAND,ΤΑ ΣΤΟΙΧΕΙΑ ΤΟΝ ΚΡΥΣΤΑΛΟΥ #####################
    ####################################################################################################
    
    top_atomtypes_temp=[]
    for i in range(len(atoma_pdb)):
        top_atomtypes_temp.append([atoma_pdb[i],atoma_pdb[i],top_atomtypes_pd.iloc[i,2],top_atomtypes_pd.iloc[i,3],top_atomtypes_pd.iloc[i,4],'{:.5e}'.format(sigma[i]),'{:.5e}'.format(epsilon[i]),top_atomtypes_pd.iloc[i,7],str(round((sigma[i]/(2**0.83333)*10),2)),str(round((epsilon[i]/4.184),4))])
    top_atomtypes_temp=pd.DataFrame(top_atomtypes_temp)
    top_atomtypes_pd = pd.concat([top_atomtypes_temp, top_atomtypes_pd]).reset_index(drop = True)
    #round((sigma/(2**0.83333)*10),4)
    #round((epsilon/4.184)),4)
    top_atoms_temp=[]
    for i in range(len(pdb_coords)):
        top_atoms_temp.append([pdb_arxeio.iloc[i,1],pdb_arxeio.iloc[i,2],'1',pdb_arxeio.iloc[i,2],pdb_arxeio.iloc[i,2],pdb_arxeio.iloc[i,1],'0.000000','{:.5f}'.format(atomic_masses[atomic_numbers[("".join(x for x in pdb_arxeio.iloc[i,2] if x.isalpha())).capitalize()]]),top_ligands_atoms.iloc[0,8],top_ligands_atoms.iloc[0,9],'0.000'])
    top_atoms_temp=pd.DataFrame(top_atoms_temp)
    top_ligands_atoms=pd.concat([top_atoms_temp, top_ligands_atoms]).reset_index(drop = True)
    top_ligands_atoms=top_ligands_atoms.astype(str)
    
    
    
    ####################################################################################################
    ##################              ΓΡΑΦΩ ΤΟ TOPOLOGY FILE            ##################################
    ####################################################################################################    
    
    #DIAVAZW TA ARXIKA KAI TA TELEYTAIA APO TOP
    with open('test_GMX.top','r') as itp:
        itp_lines=itp.readlines()
        topol_arxika=("".join(itp_lines[0:6]))
        topol_telika=("".join(itp_lines[8:]))
    
    
    
    
    
    zzz=open(pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_no_bonded.top', 'w')        #DHMIOURGW TO TOPOLOGY ARXEIO
    
    zzz.write(topol_arxika)
    
    for item in top_atomtypes:                #GRAFW TO ATOMTYPES
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_atomtypes_pd)):
        zzz.write(' '+(top_atomtypes_pd.iloc[i,0].upper()).ljust(9))
        zzz.write(''+(top_atomtypes_pd.iloc[i,1].upper()).ljust(4))
        zzz.write(''+(top_atomtypes_pd.iloc[i,2].rjust(17)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,3].rjust(9)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,4].rjust(4)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,5].rjust(16)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,6].rjust(14)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,7].rjust(2)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,8].rjust(5)))
        zzz.write(''+(top_atomtypes_pd.iloc[i,9].rjust(8))+'\n')
    zzz.write("\n")
    
    for item in top_moleculetype:               #GRAFW TO MOLECULETYPE
        zzz.write("%s\n" % item.rstrip())
    zzz.write("\n")   
    
    for item in top_atoms:                      #GRAFW TA ATOMS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_atoms)):
        zzz.write(''+(top_ligands_atoms.iloc[i,0]).rjust(6))
        zzz.write(''+((top_ligands_atoms.iloc[i,1]).upper()).rjust(5))
        zzz.write(''+(top_ligands_atoms.iloc[i,2]).rjust(6))
        zzz.write(''+(top_ligands_atoms.iloc[i,3].rjust(6)))
        zzz.write(''+(top_ligands_atoms.iloc[i,4].rjust(6)))
        zzz.write(''+((top_ligands_atoms.iloc[i,5]).rjust(5)))
        zzz.write(''+(top_ligands_atoms.iloc[i,6].rjust(13)))
        zzz.write(''+(top_ligands_atoms.iloc[i,7].rjust(13)))
        zzz.write(''+(top_ligands_atoms.iloc[i,8].rjust(2)))
        zzz.write(''+(top_ligands_atoms.iloc[i,9].rjust(5)))
        zzz.write(''+(top_ligands_atoms.iloc[i,10].rjust(8))+'\n')
    zzz.write("\n")

    for item in top_bonds:                      #GRAFW TA BONDS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_bonds)):
        zzz.write(''+(top_ligands_bonds.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_bonds.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_bonds.iloc[i,2]).rjust(4))
        zzz.write(''+(top_ligands_bonds.iloc[i,3]).rjust(14))
        zzz.write(''+(top_ligands_bonds.iloc[i,4]).rjust(14))
        zzz.write(''+(top_ligands_bonds.iloc[i,5]).rjust(2))
        zzz.write(''+(top_ligands_bonds.iloc[i,6]).rjust(7))
        zzz.write(''+(top_ligands_bonds.iloc[i,7]).rjust(2))
        zzz.write(''+(top_ligands_bonds.iloc[i,8]).rjust(3)+'\n')
    zzz.write("\n")
    
    for item in top_pairs:                      #GRAFW TA PAIRS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_pairs)):
        zzz.write(''+(top_ligands_pairs.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_pairs.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_pairs.iloc[i,2].rjust(7)))
        zzz.write(''+(top_ligands_pairs.iloc[i,3].rjust(2)))
        zzz.write(''+(top_ligands_pairs.iloc[i,4]).rjust(7))
        zzz.write(''+(top_ligands_pairs.iloc[i,5]).rjust(2))
        zzz.write(''+(top_ligands_pairs.iloc[i,6]).rjust(3)+'\n')
    zzz.write("\n")
    
    for item in top_angles:                      #GRAFW TA ANGLES
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_angles)):
        zzz.write(''+(top_ligands_angles.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_angles.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,2].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,3]).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,4]).rjust(14))
        zzz.write(''+(top_ligands_angles.iloc[i,5]).rjust(14))
        zzz.write(''+(top_ligands_angles.iloc[i,6]).rjust(2))
        zzz.write(''+(top_ligands_angles.iloc[i,7]).rjust(7))
        zzz.write(''+(top_ligands_angles.iloc[i,8]).rjust(2))
        zzz.write(''+(top_ligands_angles.iloc[i,9]).rjust(3))
        zzz.write(''+(top_ligands_angles.iloc[i,10]).rjust(6))
        zzz.write(''+(top_ligands_angles.iloc[i,11]).rjust(3)+'\n')
    zzz.write("\n")
    
    for item in top_propers:                      #GRAFW TA DIHEDRALS -PROPERS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_propers)):
        zzz.write(''+(top_ligands_propers.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_propers.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,2].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,3].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,4]).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,5]).rjust(9))
        zzz.write(''+(top_ligands_propers.iloc[i,6]).rjust(10))
        zzz.write(''+(top_ligands_propers.iloc[i,7]).rjust(4))
        zzz.write(''+(top_ligands_propers.iloc[i,8]).rjust(2))
        zzz.write(''+(top_ligands_propers.iloc[i,9]).rjust(8))
        zzz.write(''+(top_ligands_propers.iloc[i,10]).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,11]).rjust(7))
        zzz.write(''+(top_ligands_propers.iloc[i,12]).rjust(6)+'\n')
    zzz.write("\n")
    
    for item in top_impropers:                      #GRAFW TA DIHEDRALS -IMPROPERS
        zzz.write("%s\n" % item.rstrip())
    for i in range(len(top_ligands_impropers)):
        zzz.write(''+(top_ligands_impropers.iloc[i,0].astype(str)).rjust(6))
        zzz.write(''+(top_ligands_impropers.iloc[i,1].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,2].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,3].astype(str)).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,4]).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,5]).rjust(9))
        zzz.write(''+(top_ligands_impropers.iloc[i,6]).rjust(10))
        zzz.write(''+(top_ligands_impropers.iloc[i,7]).rjust(4))
        zzz.write(''+(top_ligands_impropers.iloc[i,8]).rjust(2))
        zzz.write(''+(top_ligands_impropers.iloc[i,9]).rjust(8))
        zzz.write(''+(top_ligands_impropers.iloc[i,10]).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,11]).rjust(7))
        zzz.write(''+(top_ligands_impropers.iloc[i,12]).rjust(6)+'\n')

    zzz.write(topol_telika)
    zzz.close()
    
    print('Teleiwsa to top file...')
    
    
    #DHMIOURGW TO PDB ARXEIO#
    print('Dhmiourgw to pdb arxeio...')
    temp_ligands=round(final_ligands,3).copy()
    temp_ligands.insert(3,'res',top_atoms_pd.iloc[0,3])
    temp_last_col=[]
    for i in range(len(temp_ligands)):
        temp_last_col.append(ligand_stoixeia_1[i][0])
    temp_ligands.insert(4,'lc',temp_last_col)
    temp_ligands.insert(0,'st',ligand_stoixeia_1)

    
    temp_pdb=(pdb_arxeio.iloc[:,3:6].copy()).astype(float)
    temp_pdb.insert(3,'res',pdb_arxeio.iloc[:,2])
    temp_pdb.insert(4,'lc',(pdb_arxeio.iloc[:,2].str.upper()))
    temp_pdb.insert(0,'st',pdb_arxeio.iloc[:,2])

    temp_teliko = pd.DataFrame( np.concatenate( (temp_pdb.values, temp_ligands.values), axis=0 ) )


    ##### ΦΤΙΑΧΝΩ ΤΟ CONNECT ############
    connect_2=[]
    for i in range(len(connect_1)):
        connect_2.append(np.hstack(connect_1[i]))

    connect_2=pd.DataFrame(connect_2)



    connect_2=connect_2+len(pdb_arxeio)
    
    l=len(connect_2)
    for i in range(0,len(gwnies_ligand)):
        connect.append(connect_2+(l*i))
    
    cell=[]
    for i in range(len(connect)):
        for j in range(len(connect[0])):
            cell.append((np.array(connect[i].loc[j])))
    
    cell2=np.array(cell).astype(int)
    cell1=np.where(cell2<0,'',cell2)
    
    temp_teliko.iloc[:,1:4]=temp_teliko.iloc[:,1:4].astype(float)
    zzz1=open(pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_no_bonded.pdb', 'w')

    for i in range(len(temp_teliko)):
        if len(top_ligands_atoms.iloc[i,4])<=3:
            zzz1.write('HETATM{:>5}  {:<3} {:<3}{:>6}{:12.3f}{:8.3f}{:8.3f}{:>6.2f}{:>6.2f}{:>12}\n'.format(str(top_ligands_atoms.iloc[i,0]),top_ligands_atoms.iloc[i,4],top_ligands_atoms.iloc[i,3],top_ligands_atoms.iloc[i,2],temp_teliko.iloc[i,1],temp_teliko.iloc[i,2],temp_teliko.iloc[i,3],0,0,(''.join(filter(str.isalpha, top_ligands_atoms.iloc[i,4]))).upper()))
        else:
            zzz1.write('HETATM{:>5} {:<4} {:<3}{:>6}{:12.3f}{:8.3f}{:8.3f}{:>6.2f}{:>6.2f}{:>13}\n'.format(str(top_ligands_atoms.iloc[i,0]),top_ligands_atoms.iloc[i,4],top_ligands_atoms.iloc[i,3],top_ligands_atoms.iloc[i,2],temp_teliko.iloc[i,1],temp_teliko.iloc[i,2],temp_teliko.iloc[i,3],0,0,(''.join(filter(str.isalpha, top_ligands_atoms.iloc[i,4]))).upper()))

    zzz1.write("CONECT{:}".format(''))
    for i in range(len(cell1)):   
        for j in range(len(cell1[0])):
            if cell1[i][j] =='':
                pass
            else:
                zzz1.write("{:>5}".format(str(cell1[i][j])))
        zzz1.write("\nCONECT{:}".format(''))
    zzz1.close()
    deleter="'"+pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_no_bonded.pdb'+"'"
    #os.system('sed -i "$ d" {0}'.format(deleter))
    print('Teleiwsa to pdb arxeio...')    
   
    
    print('Dhmiourgw to gro arxeio...')
    zzz2=open(pdb_info_name.split('.')[0]+'+'+ligand_info_name.split('.')[0]+'_no_bonded.gro','w')
    zzz2.write(str('Created by John Nasto')+'\n')
    zzz2.write('{:>5}\n'.format(len(temp_teliko)))
    for i in range(len(temp_teliko)):
        zzz2.write('{:>5}{:>5}{:>5}{:>5}{:8.3f}{:8.3f}{:8.3f}\n'.format(top_ligands_atoms.iloc[i,2],temp_teliko.iloc[i,4],temp_teliko.iloc[i,0],str(i+1),temp_teliko.iloc[i,1]*0.1,temp_teliko.iloc[i,2]*0.1,temp_teliko.iloc[i,3]*0.1))
    zzz2.write('    0.00000     0.00000     0.00000'+'\n')
    zzz2.close()
    print('Teleiwsa to gro arxeio...')
    os.system("mv "+ligand_info_name+" "+pdb_info_name+ " "+ pdb_info_name.split('.')[0]+'_and_'+ligand_info_name.split('.')[0]+"/")
    os.system("rm -rf test*")
    os.system("mv *+*.pdb *+*.gro *+*.top "+pdb_info_name.split('.')[0]+'_and_'+ligand_info_name.split('.')[0]+"/")
    helper = open ('help.txt','w')
    helper.write(str(pdb_info_name.split('.')[0]+'_and_'+ligand_info_name.split('.')[0]))
    helper.close()
    teliko_teliko=open('ok.html','w')
    teliko_teliko.write('ok')
    teliko_teliko.close()
    print('Telos programmatos')
    
    
    
    
    
    
    
