<!DOCTYPE html>
<html>
    <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
    
      <title>NASTOS web-tool</title>
    	<style>
    	.center {
    	  margin: 0;
    	  position: absolute;
    	  top: 50%;
    	  left: 50%;
    	  -ms-transform: translate(-50%, -50%);
    	  transform: translate(-50%, -50%);
    	}
    </style>
    <link rel="stylesheet" href="css/nastos_par.css">
    </head>
	<body>
        <?php
        session_start();
        $session_id_1 = session_id();
        $_SESSION['met']= $session_id_1;
        session_write_close();
        //setcookie($session_id_1, time() + (86400 * 30), "/"); // 86400 = 1 day
        //remove <script></script> and add php start and close tag
        //comment these two lines when code started working fine
        error_reporting(E_ALL);
        ini_set('display_errors',1);
        $filename1 = 'uploads/'.session_id().'/pdb.txt';
        $eachlines1 = file($filename1, FILE_IGNORE_NEW_LINES);
        $filename2 = 'uploads/'.session_id().'/ligand.txt';
        $eachlines2 = file($filename2, FILE_IGNORE_NEW_LINES);
        
        ?>
        <h1 class="display-3">The web-server for automatic creation of functionalized nanoparticles </h1>
        <form name="testForm" class="login" action="preloader.php" method="post" enctype="multipart/form-data">
        <div id="page-wrap" class = "pdb">
            <p1>Select the element of the <span class="doubleUnderline">nanocrystal</span> that will interact with the ligand</p1>
            <select id="pdb" class = "pdb_file" name="pdb1" size="<?= $eachlines1[0] ?>" onclick="myFunction();" required>
                
               <?php

    				$counter = 0;
    				foreach($eachlines1 as $lines){ //add php code here
    					if ($counter++ == 0) continue;
    					echo "<option value='".$lines."'>$lines</option>";
                }?>
    
            </select>
        </div>
        <div id="demo" name="demo" class='demo'></div>
        <div id="page-wrap" class = "lig">
            <p2>Select the element of the <span class="doubleUnderline">ligand</span> that will interact with the nanocrystal</p2>
            <select id="ligand" class = "lig_file" size="<?= $eachlines2[0] ?>" style="height:800%" onclick="myFunction();" required>
                
               <?php

    				$counter = 0;
    				foreach($eachlines2 as $lines){ //add php code here
    					if ($counter++ == 0) continue;
    					echo "<option value='".$lines."'>$lines</option>";
                }?>
            </select>
         </div >
    	<div id="demo1" name="demo1" class='demo1'></div>
    		<br><br>
    	<div id="sigma_epsilon_1" name="sigma_epsilon_1" class='sigma_epsilon_1'></div>
		<div id="opener" name="opener" class='opener'>
    		<p id="graft" name="graft" " required></p><br>
    		<p id="check" name="check" onchange="myFunction1()"></p><br>
    		
    		<p id="length_no_bond" name="length_no_bond"></p>
    		<p id="length_no_bond" name="length_no_bond" style="display:none"></p>
    		<p id="length_bond" name="length_bond" style="display:none" ></p>
    		<p3 id="sigma_epsilon" name="sigma_epsilon" required></p3><br><br><br>
    		<div id="opener1" name="opener1" class='opener1'>
    			<p4 id="kbb0" name="kbb0"></p4>
    			<p4 id="kthth0" name="kthth0"></p4>
    			<p4 id="kff0" name="kff0"></p4><br><br><br>
    			<p id="note" name="note"></p>
    		</div>
    		<input type="submit" value="Upload" onclick="myFunction_teliki();">
    		<p id="status" name="status"></p>
		</div>
    		</form>

	
        <script>
        
        
        
        function myFunction() {
            myFunction.counter += 1
            // Create our XMLHttpRequest object
            var hr = new XMLHttpRequest();
            // Create some variables we need to send to our PHP file
            var url = ".upload2.php";
            var x = document.getElementById("pdb").value;
            var y = document.getElementById("ligand").value;
            var z = "<?php echo $session_id_1; ?>";
            
            document.getElementById("demo").innerHTML = "You have selected the \"" + x +"\" from the nanocrystal elements";
            document.getElementById("demo1").innerHTML = "You have selected the \"" + y +"\" from the ligand elements";
            //document.getElementById("demo2").innerHTML = "The distance between "+x+" and "+y +" is: ";
            var vars = "pdb="+x+"&mol="+y+"&ses="+z;
            hr.open("POST", url, true);
            hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");


            
            hr.onreadystatechange = function() {
                console.log(hr);
            
                if(hr.readyState == 4 && hr.status == 200) {
                    var return_data = hr.responseText.split(" ");
                    var return_data1 = hr.responseText;
                    

                    //sigmaepsilon.innerHTML = "Sigma gia to " + return_data[0]+ " love ";
                    //sigmaepsilon.appendChild(input4);
                    //document.getElementById("test").appendChild(sigmaepsilon);

         

                    
                    if (return_data[0] == "******") { //Just leave it blank
                    	document.getElementById("sigma_epsilon_1").innerHTML = return_data1;
                    } else {
            		document.getElementById("graft").innerHTML = "";    
            		document.getElementById("check").innerHTML = "";
            		document.getElementById("length_bond").innerHTML = "";
            		document.getElementById("length_no_bond").innerHTML = "";
            		document.getElementById("sigma_epsilon").innerHTML = "";
            		//document.getElementById("sigma_epsilon_1").innerHTML = "";


                        var input = document.createElement("input");
                        input.type = "number";
                        input.min="0";
                        input.step=".01";
                        input.placeholder="e.g   "+ return_data[0] +" chains/nm²";
                        input.required = true;
                        var graft1 = document.createElement("P");
                        graft1.innerHTML = "=> The recommended grafting density between " + x + " and  " + y +" is " + return_data[0] +" chains/nm² , (we recommend you to use this) but you can enter your own value: ";
                        graft1.appendChild(input);
                        document.getElementById("graft").appendChild(graft1);
                        
                        //.required = true;

                        var input3 = document.createElement("input");
                        input3.type = "checkbox";
                        input3.id="check";
                        var graft2 = document.createElement("P");
                        graft2.innerHTML = "=> Do you want to create a bond between " + x + " and  " + y +" elements? " ;
                        graft2.appendChild(input3);
                        document.getElementById("check").appendChild(graft2);

                        
                        var input1 = document.createElement("input");
                        input1.type = "number";
                        input1.min="0";
                        input1.step=".01";
                        input1.value= parseFloat(return_data[1]) ;
                        input1.placeholder="e.g   "+ return_data[1] +" nm";
                        var length1 = document.createElement("P");
                        length1.innerHTML = "=> From our database, the distance between " + x + " and  " + y +" is " + return_data[1] +" nm , but you can enter your own value (or leave it in the default value): ";
                        length1.appendChild(input1);  
                        document.getElementById("length_bond").appendChild(length1);


                        var input2 = document.createElement("input");
                        input2.type = "number";
                        input2.min="0";
                        input2.step=".01";
                        input2.placeholder="e.g   "+ return_data[1];
                        input2.required = true;
                        //input2.setCustomValidity('Required email address');
                        var length2 = document.createElement("P");
                        length2.innerHTML = "=> Input the desired distance between " + x + " and  " + y +" in (nm) ";
                        length2.appendChild(input2);
                        document.getElementById("length_no_bond").appendChild(length2);


                        var kb1 = document.createElement("input");
                        kb1.type = "number";
                        kb1.min="0";
                        kb1.step=".01";
                        var b01 = document.createElement("input");
                        b01.type = "number";
                        b01.min="0";
                        b01.step=".01";
                        kb= document.createElement("tr");
                        kb.innerHTML = "=> Enter the bond force constant (kb): " ;
                        kb.appendChild(kb1);
                            
                        b0=document.createElement("td");
                        b0.innerHTML = "  and the bond in equilibrium length (b0): " ;
                        b0.appendChild(b01);
                        
                        kb.appendChild(b0);
                        document.getElementById("kbb0").appendChild(kb);


                        var kth1 = document.createElement("input");
                        kth1.type = "number";
                        kth1.min="0";
                        kth1.step=".01";
                        var th01 = document.createElement("input");
                        th01.type = "number";
                        th01.min="0";
                        th01.step=".01";
                        kth= document.createElement("tr");
                        kth.innerHTML = "=> Enter the angle force constant (kθ): " ;
                        kth.appendChild(kth1);    
                        th0=document.createElement("td");
                        th0.innerHTML = "  and the angle (θ0): " ;
                        th0.appendChild(th01);
                        kth.appendChild(th0);
                        document.getElementById("kthth0").appendChild(kth);
                        
                        var kf1 = document.createElement("input");
                        kf1.type = "number";
                        kf1.min="0";
                        kf1.step=".01";
                        kf1.style.width = "125px";
                        var f01 = document.createElement("input");
                        f01.type = "number";
                        f01.min="0";
                        f01.step=".01";
                        f01.style.width = "125px";
                        var n11= document.createElement("input");
                        n11.type = "number";
                        n11.min="0";
                        n11.style.width = "125px";
                        kf= document.createElement("tr");
                        kf.innerHTML = "=> Enter the force constant for the dihedral angle (kφ): " ;
                        kf.appendChild(kf1);    
                        f0=document.createElement("td");
                        f0.innerHTML = ",the dihedral angle (φ0): " ;
                        f0.appendChild(f01);
                        n1=document.createElement("td");
                        n1.innerHTML = " and the periodicity of the dihedral angle n1: " ;
                        n1.appendChild(n11);

                        
                        kf.appendChild(f0);
                        kf.appendChild(n1);
                        document.getElementById("kff0").appendChild(kf);

                        



                    	var sigma = [];
                    	var epsilon = [];
                    	var text1=[];
                        
                        for(var i = 0; i < return_data.length-2; i += 1) {

                            var input4 = document.createElement("input");
                            input4.type = "number";
                            input4.min="0";
                            input4.step=".000001";
                            input4.placeholder=" \"3.20\" = \"3.20000e+00\"";
                            input4.required = true;
                            var input5 = document.createElement("input");
                            input5.type = "number";
                            input5.step=".000001";
                            input5.min="0";
                            input5.placeholder="\"0.05\" = \"5.00000e-02\"";
                            input5.required = true;

                            sigma[i]= document.createElement("tr");
                            sigma[i].innerHTML = "=> Enter the sigma : " ;
                            sigma[i].appendChild(input5);
                            
                            epsilon[i]=document.createElement("td");
                            epsilon[i].innerHTML = " and the epsilon: " ;
                            epsilon[i].appendChild(input4);

                            text1[i]=document.createElement("td");
                            text1[i].innerHTML = " parameters for the " + return_data[i+2] +" element" ;
                            
                            
                            sigma[i].appendChild(epsilon[i]);
                            sigma[i].appendChild(text1[i]);
                    		document.getElementById("sigma_epsilon").appendChild(sigma[i]);
                    		
                        	//document.getElementById("test").appendChild(sigmaepsilon1);
                        }
                        
                    //document.getElementById("length").innerHTML = "The length between " + x + " and  " + y +" is " +graft_and_len[2] +"."+graft_and_len[3]+" nm";
                    //document.getElementById("box").innerHTML = "Check this box if you want to exist bond"

                    	//var note = document.createElement("P");
                    	//var note1="-0.2"
                        //note.innerHTML = "&#10071; &#10071; &#10071; Note: If sigma/epsilon value is e.g. \"0.01\"  that means that sigma/epsilon in topolology file will be converted to \"1.00000e-02\" &#10071; &#10071; &#10071;";
                        //document.getElementById("note").appendChild(note);
                    }
                }
            }
            // Send the data to PHP now... and wait for response to update the demo div
            hr.send(vars); // Actually execute the request
            //document.getElementById("graft").innerHTML = "Waiting for culculations...";
            document.getElementById("graft").innerHTML = "";	
            document.getElementById("check").innerHTML = "";
            document.getElementById("length_bond").innerHTML = "";
            document.getElementById("length_no_bond").innerHTML = "";
            document.getElementById("sigma_epsilon").innerHTML = "";
            //document.getElementById("sigma_epsilon_1").innerHTML = "";
            document.getElementById("note").innerHTML = "";
        }
             
        function myFunction1() {
      	  var checkBox = document.querySelector("#opener > p:nth-child(3) > p:nth-child(1) > input:nth-child(1)");
      	  var text = document.getElementById("length_bond");
      	  var text1 = document.getElementById("length_no_bond");
      	  var req = document.querySelector("#opener > p:nth-child(5) > p:nth-child(1) > input:nth-child(1)");
      	  if (checkBox.checked == true){
      	    text.style.display = "block";
      	    text1.style.display = "none";
      	  	//req.value = "0.00";
      	    req.required = false;
      	  } else {
      	     text.style.display = "none";
      	     text1.style.display = "block";
      	     req.required = true;
      	     req.value = "";
      	  }
      
       }
        
        function myFunction_teliki() {
            var hrn = new XMLHttpRequest();
            var hrs = new XMLHttpRequest();
        	// Create some variables we need to send to our PHP file
            var url = ".upload_inputs.php";
	    var url1 = "upload4.php";

            var pdb = document.getElementById("pdb").value;
            var lig = document.getElementById("ligand").value;

            var graft = document.querySelector("#graft > p:nth-child(1) > input:nth-child(1)").value;


	    var check = document.querySelector("#opener > p:nth-child(3) > p:nth-child(1) > input:nth-child(1)").checked;

	    var len_no_bon = document.querySelector("#opener > p:nth-child(5) > p:nth-child(1) > input:nth-child(1)").value;
            var len_bon = document.querySelector("#length_bond > p:nth-child(1) > input:nth-child(1)").value;

            var sigma_epsilon= document.getElementById("sigma_epsilon").childElementCount; 

            var sigma =[];
            var epsilon =[];
            for(var i = 0; i < sigma_epsilon; i += 1) {
            	var k=i+1;
            	sigma[i] = document.querySelector("#sigma_epsilon > tr:nth-child("+k+") > input:nth-child(1)").value;
            	epsilon[i] = document.querySelector("#sigma_epsilon > tr:nth-child("+k+") > td:nth-child(2) > input:nth-child(1)").value;
            }
        	//sigmaa= document.querySelector("#sigma_epsilon > tr:nth-child(1) > input:nth-child(1)").value;
            var z1 = "<?php echo $session_id_1; ?>";
            var vars = "pdb="+pdb+"&lig="+lig+"&graft="+graft+"&check="+check+"&len_no_bon="+len_no_bon+"&len_bon="+len_bon+"&sigma="+sigma+"&epsilon="+epsilon+"&ses="+z1;
            hrn.open("POST", url, true);
            hrn.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        	// Access the onreadystatechange event for the XMLHttpRequest object
            hrn.onreadystatechange = function() {
        	console.log(hrn);

        	if(hrn.readyState == 4 && hrn.status == 200) {
        	    var return_data = hrn.responseText;
        	    document.getElementById("status").innerHTML = return_data;
        	}
            }
		// Send the data to PHP now... and wait for response to update the status div
	    hrn.send(vars);
            //document.getElementById("status").innerHTML = "processing";
            function name() {
                var browserName = '';
                var userAgent = navigator.userAgent;
                (typeof InstallTrigger !== 'undefined') && (browserName = 'Firefox');
                ( /* @cc_on!@*/ false || !!document.documentMode) && (browserName = 'IE');
                (!!window.chrome && userAgent.match(/OPR/)) && (browserName = 'Opera');
                (!!window.chrome && userAgent.match(/Edge/)) && (browserName = 'Edge');
                (!!window.chrome && !userAgent.match(/(OPR|Edge)/)) && (browserName = 'Chrome');
                return browserName;
            }

            var elem =name();
            if (elem == "Firefox"){
            	hrs.open("POST", url1, false);
            	hrs.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	    	hrs.send(vars)
	    }

        }

        </script>
		<script src="js/nastos.js"></script> 
	</body>
</html>

