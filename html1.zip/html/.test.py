#!/usr/bin/env python
import os,sys
import numpy as np
import json
import pandas as pd
import math
import re
from scipy.spatial import ConvexHull

path1=os.getcwd()+"/uploads/"+sys.argv[1]
os.chmod(path1,0o777)
os.chdir(path1) 

with open('contain.txt') as contain:
    filename1="".join(contain.readline().split())
    filename2="".join(contain.readline().split())
    
    
with open(filename1) as pdb:
    pdb_arxeio=[]
    pdb_lines=pdb.readlines()


    for i in pdb_lines:
        if i.startswith('HETATM') or i.startswith('ATOM'):
            pdb_arxeio.append("".join(i).split())

pdb_arxeio=pd.DataFrame(pdb_arxeio)

atoma_pdb=[]
for i in range(len(pdb_arxeio)):
    if pdb_arxeio.iloc[i,2] not in atoma_pdb:
        atoma_pdb.append(pdb_arxeio.iloc[i,2])

zzz1=open('pdb.txt','w')
zzz1.write(str(len(atoma_pdb))+'\n')
for i in range(len(atoma_pdb)): 
    zzz1.write('{:}\n'.format(atoma_pdb[i]))
zzz1.close() 




with open(filename2) as lig:
   lig_lines=lig.readlines()
   for i in range(len(lig_lines)):
       if lig_lines[i].startswith('@<TRIPOS>ATOM'):
           arxi=i+1
       if lig_lines[i].startswith('@<TRIPOS>BOND'):
          mesh=i
       if lig_lines[i].startswith('@<TRIPOS>SUBSTRUCTURE'):
           telos=i
ligand_file= "".join(lig_lines[arxi:mesh])
ligand_file_bond= "".join(lig_lines[mesh+1:telos])
ligand_file_pd = pd.DataFrame([x.split() for x in ligand_file.split('\n')])
ligand_file_bond=pd.DataFrame([x.split() for x in ligand_file_bond.split('\n')])
ligand_file_pd=ligand_file_pd.drop(ligand_file_pd.index[-1])
ligand_file_bond=ligand_file_bond.drop(ligand_file_bond.index[-1])
ligand_coords_arxiko=np.array(ligand_file_pd.iloc[:,2:5],dtype=float)
ligand_file_bond=np.array(ligand_file_bond.iloc[:,1:3],dtype=int)
ligand_stoixeia=ligand_file_pd.iloc[:,1]


zzz2=open('ligand.txt','w')
zzz2.write(str(len(ligand_stoixeia))+'\n')
for i in range(len(ligand_stoixeia)): 
    zzz2.write('{:}\n'.format(ligand_stoixeia[i]))
zzz2.close() 





os.chdir("../../")


