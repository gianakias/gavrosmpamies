<?php 
$data= $_POST['data'];
while (true){
    if (file_exists("uploads/".$data."/ok.html")){
        break;
    } else{
        //pass
    }
}
echo "OK";
?>
