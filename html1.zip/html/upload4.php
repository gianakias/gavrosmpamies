<?php
//session_start();
//$session_id_1 =session_id();
//session_write_close();
$pdb = $_POST['pdb'];
$lig = $_POST['lig'];
$graft = $_POST['graft'];
$check = $_POST['check'];
$len_no_bon = $_POST['len_no_bon'];
$len_bon = $_POST['len_bon'];
$sigma =$_POST['sigma'];
$epsilon =$_POST['epsilon'];
$session_id_1 = $_POST['ses'];

?>
